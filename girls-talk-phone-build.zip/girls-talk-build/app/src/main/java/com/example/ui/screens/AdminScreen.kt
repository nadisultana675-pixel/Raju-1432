package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VerificationStatus
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.Strings
import com.example.viewmodel.GirlsTalkViewModel
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.UiState

@Composable
fun AdminDashboardScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    var adminTab by remember { mutableStateOf(0) } // 0 = Verifications, 1 = Moderation & Reports, 2 = Security Logs

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        // Admin Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Admin Portal",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = PlayfairFontFamily,
                                color = GoldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)),
                            color = Color(0x33D4AF37)
                        ) {
                            Text(
                                text = "RESTRICTED",
                                color = GoldAccent,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Logged in as ${state.currentUser.name}",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp)
                    )
                }
            }

            GoldOutlinedButton(
                text = "Exit Portal",
                onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) },
                modifier = Modifier.height(34.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // High-level Stats Overview Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminStatCard("Total Users", "2,490", Icons.Default.People, Modifier.weight(1f))
            AdminStatCard("Verified 18+", "2,410", Icons.Default.Verified, Modifier.weight(1f))
            AdminStatCard("Pending", "${state.verificationRequests.count { it.status == VerificationStatus.PENDING }}", Icons.Default.HourglassTop, Modifier.weight(1f))
            AdminStatCard("Reports", "${state.adminReports.count { it.status == "PENDING" }}", Icons.Default.Flag, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Admin Sub-tabs
        TabRow(
            selectedTabIndex = adminTab,
            containerColor = CardSurface,
            contentColor = GoldPrimary,
            indicator = { /* standard */ },
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
        ) {
            Tab(
                selected = adminTab == 0,
                onClick = { adminTab = 0 },
                text = { Text("ID Reviews (${state.verificationRequests.size})", fontSize = 12.sp, color = if (adminTab == 0) GoldPrimary else TextLightGrey) }
            )
            Tab(
                selected = adminTab == 1,
                onClick = { adminTab = 1 },
                text = { Text("Reports (${state.adminReports.size})", fontSize = 12.sp, color = if (adminTab == 1) GoldPrimary else TextLightGrey) }
            )
            Tab(
                selected = adminTab == 2,
                onClick = { adminTab = 2 },
                text = { Text("Audit Logs", fontSize = 12.sp, color = if (adminTab == 2) GoldPrimary else TextLightGrey) }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tab Content
        when (adminTab) {
            0 -> VerificationQueueTab(state, viewModel)
            1 -> ModerationReportsTab(state, viewModel)
            2 -> AuditLogsTab(state)
        }
    }
}

@Composable
private fun AdminStatCard(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(0.5.dp, GoldBorder, RoundedCornerShape(12.dp)),
        color = CardSurface
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, style = MaterialTheme.typography.titleMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
            Text(text = label, style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 9.sp))
        }
    }
}

@Composable
private fun VerificationQueueTab(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(state.verificationRequests) { req ->
            GoldCard(
                modifier = Modifier.fillMaxWidth(),
                borderWidth = 1.dp,
                borderColor = if (req.status == VerificationStatus.VERIFIED) GoldPrimary else GoldBorder,
                backgroundColor = CardSurface
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AvatarWithStatus(user = req.user, size = 46.dp, showOnlineStatus = false)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = req.user.name,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                            Text(
                                text = "Age: ${req.user.age} • ${req.user.city}, ${req.user.country}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextLightGrey)
                            )
                        }
                    }

                    VerifiedBadge(status = req.status)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    color = CharcoalBg
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "Document: ${req.documentType}", style = MaterialTheme.typography.bodySmall.copy(color = GoldLight, fontWeight = FontWeight.Bold))
                        Text(text = "Encrypted ID Ref: ${req.documentNumberMasked}", style = MaterialTheme.typography.bodySmall.copy(color = TextLightGrey))
                        Text(text = "Submitted: ${req.submittedDate}", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 10.sp))
                    }
                }

                if (req.status == VerificationStatus.PENDING) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GoldButton(
                            text = "Approve (18+ Verified)",
                            onClick = { viewModel.approveVerification(req.id) },
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Check
                        )
                        GoldOutlinedButton(
                            text = "Reject",
                            onClick = { viewModel.rejectVerification(req.id) },
                            modifier = Modifier.weight(0.6f)
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun ModerationReportsTab(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(state.adminReports) { rep ->
            GoldCard(
                modifier = Modifier.fillMaxWidth(),
                borderWidth = 1.dp,
                borderColor = DangerRed.copy(alpha = 0.6f),
                backgroundColor = CardSurface
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = DangerRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Flagged: ${rep.reportedUser.name}",
                            style = MaterialTheme.typography.titleMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold)
                        )
                    }
                    Surface(
                        modifier = Modifier.clip(RoundedCornerShape(6.dp)),
                        color = Color(0x33E53935)
                    ) {
                        Text(
                            text = rep.status,
                            color = DangerRed,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Reason: ${rep.reason}",
                    style = MaterialTheme.typography.bodyMedium.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
                )

                Text(
                    text = "Context: \"${rep.contextNote}\"",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextLightGrey)
                )

                Text(
                    text = "Reported by: ${rep.reporter.name} • ${rep.timestamp}",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 10.sp),
                    modifier = Modifier.padding(top = 4.dp)
                )

                if (rep.status == "PENDING") {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.resolveReport(rep.id, suspendAccount = true) },
                            colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text("Suspend Account", color = TextWhite, fontWeight = FontWeight.Bold)
                        }
                        GoldOutlinedButton(
                            text = "Dismiss",
                            onClick = { viewModel.resolveReport(rep.id, suspendAccount = false) },
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun AuditLogsTab(
    state: UiState
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(state.securityLogs) { log ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .border(0.5.dp, GoldBorder, RoundedCornerShape(10.dp)),
                color = CardSurface
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = log.action, style = MaterialTheme.typography.bodyMedium.copy(color = GoldLight, fontWeight = FontWeight.Bold))
                        Text(text = "Target: ${log.target} • IP: ${log.ipMasked}", style = MaterialTheme.typography.bodySmall.copy(color = TextLightGrey, fontSize = 11.sp))
                    }
                    Text(text = log.timestamp, style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 10.sp))
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun NotificationsScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Notification Center",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = PlayfairFontFamily,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.notifications) { item ->
                GoldCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderWidth = 0.5.dp,
                    borderColor = if (!item.isRead) GoldPrimary else GoldBorder,
                    backgroundColor = if (!item.isRead) Color(0xFF221E12) else CardSurface
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CharcoalBg)
                                .border(1.dp, GoldBorder, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (item.type) {
                                    com.example.model.NotificationType.VERIFICATION -> Icons.Default.Verified
                                    com.example.model.NotificationType.CALL -> Icons.Default.Call
                                    com.example.model.NotificationType.MESSAGE -> Icons.Default.Chat
                                    com.example.model.NotificationType.COMMUNITY -> Icons.Default.Groups
                                    com.example.model.NotificationType.ALERT -> Icons.Default.Shield
                                },
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = item.timestamp,
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 10.sp)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = item.message,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextLightGrey,
                                    lineHeight = 18.sp
                                )
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}
