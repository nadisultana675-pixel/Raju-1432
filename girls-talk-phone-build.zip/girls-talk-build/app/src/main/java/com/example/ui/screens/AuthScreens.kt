package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.AppLanguage
import com.example.util.Strings
import com.example.viewmodel.GirlsTalkViewModel
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.UiState

@Composable
fun SplashScreen(
    onTimeout: () -> Unit
) {
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2000)
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(CircleShape)
                    .border(2.dp, GoldPrimary, CircleShape)
                    .background(CharcoalBg),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_girls_talk),
                    contentDescription = "GIRLS TALK",
                    modifier = Modifier.size(110.dp)
                )
            }
            Spacer(modifier = Modifier.height(28.dp))
            Text(
                text = "GIRLS TALK",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontFamily = PlayfairFontFamily,
                    color = GoldPrimary,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "A Private Community for Verified Adult Women",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextLightGrey,
                    letterSpacing = 0.5.sp,
                    textAlign = TextAlign.Center
                )
            )
            Spacer(modifier = Modifier.height(40.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = GoldPrimary,
                strokeWidth = 2.dp
            )
        }
    }
}

@Composable
fun WelcomeScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Hero Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_luxury),
                    contentDescription = "Luxury Sanctuary",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, DeepBlack.copy(alpha = 0.6f), DeepBlack)
                            )
                        )
                )

                // Language switch top-right
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { viewModel.toggleLanguage() },
                    color = DeepBlack.copy(alpha = 0.7f)
                ) {
                    Text(
                        text = if (lang == AppLanguage.ENGLISH) "বাংলা" else "English",
                        color = GoldPrimary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            ) {
                Text(
                    text = Strings.get("app_name", lang),
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = PlayfairFontFamily,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = Strings.get("tagline", lang),
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.SemiBold
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = Strings.get("welcome_desc", lang),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextLightGrey,
                        lineHeight = 22.sp
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Safety Assurance Card
                GoldCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = GoldBorder,
                    backgroundColor = CharcoalBg
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.img_safety_shield),
                            contentDescription = "Safety",
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Strict 18+ Identity Protocol",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    color = GoldPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "Zero tolerance for fake profiles. Government ID & biometric encryption protect our private space.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextLightGrey)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Primary Action: Register
                GoldButton(
                    text = Strings.get("register", lang),
                    onClick = { viewModel.navigateTo(ScreenDestination.REGISTER) },
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Default.PersonAdd,
                    testTag = "welcome_register_button"
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Secondary Action: Login
                GoldOutlinedButton(
                    text = Strings.get("login", lang),
                    onClick = { viewModel.navigateTo(ScreenDestination.LOGIN) },
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Default.Lock,
                    testTag = "welcome_login_button"
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Direct Demo Quick Access
                Text(
                    text = "QUICK DEMO PREVIEW",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextMuted,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    GoldOutlinedButton(
                        text = Strings.get("demo_login_member", lang),
                        onClick = { viewModel.switchAccountRole(toAdmin = false) },
                        modifier = Modifier.weight(1f),
                        testTag = "demo_member_button"
                    )
                    GoldOutlinedButton(
                        text = Strings.get("demo_login_admin", lang),
                        onClick = { viewModel.switchAccountRole(toAdmin = true) },
                        modifier = Modifier.weight(1f),
                        testTag = "demo_admin_button"
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun RegisterScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        IconButton(
            onClick = { viewModel.navigateTo(ScreenDestination.WELCOME) },
            modifier = Modifier.size(40.dp)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = Strings.get("register", lang),
            style = MaterialTheme.typography.displayMedium.copy(
                fontFamily = PlayfairFontFamily,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
        )
        Text(
            text = "Join our private sanctuary for verified adult women.",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextLightGrey)
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Mobile input
        Text(
            text = Strings.get("phone_number", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = state.phoneInput,
            onValueChange = { viewModel.onPhoneChange(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("register_phone_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = {
                Icon(Icons.Default.Phone, contentDescription = null, tint = GoldPrimary)
            }
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Optional Email
        Text(
            text = Strings.get("email_optional", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = state.emailInput,
            onValueChange = { viewModel.onEmailChange(it) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = {
                Icon(Icons.Default.Email, contentDescription = null, tint = GoldPrimary)
            }
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Password
        Text(
            text = Strings.get("password", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = state.passwordInput,
            onValueChange = { viewModel.onPasswordChange(it) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = {
                Icon(Icons.Default.Lock, contentDescription = null, tint = GoldPrimary)
            }
        )

        Spacer(modifier = Modifier.height(28.dp))

        GoldButton(
            text = Strings.get("verify_continue", lang),
            onClick = { viewModel.startRegistration() },
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Default.ArrowForward,
            testTag = "submit_register_button"
        )
    }
}

@Composable
fun LoginScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        IconButton(
            onClick = { viewModel.navigateTo(ScreenDestination.WELCOME) },
            modifier = Modifier.size(40.dp)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = Strings.get("login", lang),
            style = MaterialTheme.typography.displayMedium.copy(
                fontFamily = PlayfairFontFamily,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
        )
        Text(
            text = "Welcome back to your private sisterhood sanctuary.",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextLightGrey)
        )

        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = Strings.get("phone_number", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = state.phoneInput,
            onValueChange = { viewModel.onPhoneChange(it) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = {
                Icon(Icons.Default.Phone, contentDescription = null, tint = GoldPrimary)
            }
        )

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = Strings.get("password", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = state.passwordInput,
            onValueChange = { viewModel.onPasswordChange(it) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = {
                Icon(Icons.Default.Lock, contentDescription = null, tint = GoldPrimary)
            }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = Strings.get("forgot_password", lang),
            style = MaterialTheme.typography.bodySmall.copy(color = GoldPrimary),
            modifier = Modifier
                .align(Alignment.End)
                .clickable { /* Informational */ }
        )

        Spacer(modifier = Modifier.height(28.dp))

        GoldButton(
            text = Strings.get("login", lang),
            onClick = { viewModel.switchAccountRole(toAdmin = false) },
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Default.Login,
            testTag = "login_submit_button"
        )
    }
}

@Composable
fun OtpScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            IconButton(
                onClick = { viewModel.navigateTo(ScreenDestination.REGISTER) },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .border(1.5.dp, GoldPrimary, CircleShape)
                .background(CardSurface),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Sms,
                contentDescription = null,
                tint = GoldPrimary,
                modifier = Modifier.size(34.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = Strings.get("enter_otp", lang),
            style = MaterialTheme.typography.titleLarge.copy(
                fontFamily = PlayfairFontFamily,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "${Strings.get("otp_subtitle", lang)}\n${state.phoneInput}",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = TextLightGrey,
                textAlign = TextAlign.Center
            )
        )

        Spacer(modifier = Modifier.height(32.dp))

        // OTP digits display
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 0 until 6) {
                val char = state.otpInput.getOrNull(i)?.toString() ?: ""
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(
                            1.5.dp,
                            if (char.isNotEmpty()) GoldPrimary else GoldBorder,
                            RoundedCornerShape(12.dp)
                        )
                        .background(CardSurface),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = char,
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = GoldLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Simulated quick input buttons
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { viewModel.onOtpChange("592814") }
                    .border(1.dp, GoldBorder, RoundedCornerShape(8.dp)),
                color = CardSurface
            ) {
                Text(
                    text = "Auto-fill Code: 592814",
                    color = GoldLight,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        GoldButton(
            text = Strings.get("verify_continue", lang),
            onClick = { viewModel.verifyOtp() },
            modifier = Modifier.fillMaxWidth(),
            enabled = state.otpInput.length >= 4,
            icon = Icons.Default.CheckCircle,
            testTag = "verify_otp_button"
        )
    }
}

@Composable
fun AgeIdentityVerificationScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        IconButton(
            onClick = { viewModel.navigateTo(ScreenDestination.OTP_VERIFICATION) },
            modifier = Modifier.size(40.dp)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.img_safety_shield),
                contentDescription = null,
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(6.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = Strings.get("verification_title", lang),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = PlayfairFontFamily,
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold
                )
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = Strings.get("verification_subtitle", lang),
            style = MaterialTheme.typography.bodyMedium.copy(color = TextLightGrey)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Date of Birth input (18+ requirement)
        Text(
            text = Strings.get("dob_label", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = state.dobInput,
            onValueChange = { viewModel.onDobChange(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("dob_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = {
                Icon(Icons.Default.CalendarToday, contentDescription = null, tint = GoldPrimary)
            },
            trailingIcon = {
                Text(
                    text = "Age: 29",
                    style = MaterialTheme.typography.labelSmall.copy(color = GoldPrimary),
                    modifier = Modifier.padding(end = 12.dp)
                )
            }
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Government ID Type
        Text(
            text = Strings.get("id_type_label", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(8.dp))
        val idOptions = listOf(
            Strings.get("id_nid", lang),
            Strings.get("id_passport", lang),
            Strings.get("id_drivers", lang)
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            idOptions.forEach { opt ->
                val selected = state.idTypeInput == opt || (state.idTypeInput.contains("National") && opt.contains("National"))
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .border(
                            1.dp,
                            if (selected) GoldPrimary else GoldBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { viewModel.onIdTypeChange(opt) },
                    color = if (selected) Color(0x33D4AF37) else CardSurface
                ) {
                    Text(
                        text = opt,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (selected) GoldLight else TextLightGrey,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // ID Number Reference
        Text(
            text = Strings.get("id_doc_number", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = state.idDocNumberInput,
            onValueChange = { viewModel.onIdDocNumberChange(it) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = {
                Icon(Icons.Default.Badge, contentDescription = null, tint = GoldPrimary)
            }
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Mandatory Consent Box
        GoldCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = GoldPrimary,
            backgroundColor = CharcoalBg
        ) {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.clickable {
                    viewModel.toggleVerificationConsent(!state.hasAcceptedVerificationConsent)
                }
            ) {
                Checkbox(
                    checked = state.hasAcceptedVerificationConsent,
                    onCheckedChange = { viewModel.toggleVerificationConsent(it) },
                    colors = CheckboxDefaults.colors(
                        checkedColor = GoldPrimary,
                        checkmarkColor = DeepBlack,
                        uncheckedColor = GoldBorder
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = Strings.get("verification_consent", lang),
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextWhite,
                        lineHeight = 18.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        GoldButton(
            text = Strings.get("submit_verification", lang),
            onClick = { viewModel.submitIdentityVerification() },
            modifier = Modifier.fillMaxWidth(),
            enabled = state.hasAcceptedVerificationConsent,
            icon = Icons.Default.VerifiedUser,
            testTag = "submit_identity_verification_button"
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun ProfileSetupScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    var name by remember { mutableStateOf(state.currentUser.name) }
    var city by remember { mutableStateOf(state.currentUser.city) }
    var country by remember { mutableStateOf(state.currentUser.country) }
    var bio by remember { mutableStateOf(state.currentUser.bio) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text(
            text = Strings.get("setup_profile", lang),
            style = MaterialTheme.typography.displayMedium.copy(
                fontFamily = PlayfairFontFamily,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
        )
        Text(
            text = "Personalize your sanctuary presence.",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextLightGrey)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Profile Photo with Gold Ring
        Box(
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .border(2.dp, GoldPrimary, CircleShape)
                    .background(CharcoalBg),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_avatar_sample),
                    contentDescription = "Profile",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(GoldPrimary)
                    .align(Alignment.BottomEnd),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Change photo",
                    tint = DeepBlack,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = Strings.get("display_name", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = Strings.get("city", lang),
                    style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GoldBorder,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedContainerColor = CardSurface,
                        unfocusedContainerColor = CardSurface
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = Strings.get("country", lang),
                    style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = country,
                    onValueChange = { country = it },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GoldBorder,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedContainerColor = CardSurface,
                        unfocusedContainerColor = CardSurface
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = Strings.get("bio", lang),
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = bio,
            onValueChange = { bio = it },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 4,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(28.dp))

        GoldButton(
            text = Strings.get("save_profile", lang),
            onClick = { viewModel.completeProfileSetup(name, city, country, bio) },
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Default.Check,
            testTag = "save_profile_button"
        )
    }
}
