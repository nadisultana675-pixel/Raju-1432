package com.example.model

enum class VerificationStatus {
    VERIFIED,
    PENDING,
    REJECTED,
    UNVERIFIED
}

enum class UserRole {
    MEMBER,
    ADMIN
}

data class PrivacySettings(
    val showAge: Boolean = true,
    val showLocation: Boolean = true,
    val showOnlineStatus: Boolean = true,
    val allowDirectMessages: Boolean = true,
    val allowCalls: Boolean = true
)

data class User(
    val id: String,
    val name: String,
    val username: String,
    val age: Int,
    val dateOfBirth: String,
    val city: String,
    val country: String,
    val bio: String,
    val avatarRes: Int? = null,
    val interests: List<String> = emptyList(),
    val isVerified: Boolean = true,
    val verificationStatus: VerificationStatus = VerificationStatus.VERIFIED,
    val verificationDocRef: String = "",
    val isOnline: Boolean = true,
    val lastSeen: String = "Online",
    val privacySettings: PrivacySettings = PrivacySettings(),
    val role: UserRole = UserRole.MEMBER
)

enum class MessageType {
    TEXT,
    VOICE,
    IMAGE,
    VIDEO
}

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val type: MessageType = MessageType.TEXT,
    val mediaUrl: String? = null,
    val voiceDurationSec: Int = 0,
    val timestamp: String,
    val isRead: Boolean = true,
    val isDelivered: Boolean = true
)

data class Conversation(
    val id: String,
    val participant: User,
    val lastMessage: ChatMessage,
    val unreadCount: Int = 0,
    val isBlocked: Boolean = false
)

data class CommunityPost(
    val id: String,
    val author: User,
    val content: String,
    val category: String,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val isLiked: Boolean = false,
    val timestamp: String,
    val comments: List<PostComment> = emptyList()
)

data class PostComment(
    val id: String,
    val author: User,
    val text: String,
    val timestamp: String
)

data class CommunityGroup(
    val id: String,
    val name: String,
    val nameBn: String,
    val description: String,
    val descriptionBn: String,
    val memberCount: Int,
    val category: String,
    val isJoined: Boolean = false,
    val recentDiscussion: String = ""
)

enum class CallStatus {
    IDLE,
    INCOMING,
    OUTGOING,
    ACTIVE,
    ENDED
}

data class CallSession(
    val id: String,
    val peerUser: User,
    val isVideo: Boolean,
    val status: CallStatus,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isCameraOff: Boolean = false,
    val isFrontCamera: Boolean = true
)

enum class NotificationType {
    MESSAGE,
    CALL,
    VERIFICATION,
    COMMUNITY,
    ALERT
}

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val type: NotificationType,
    val timestamp: String,
    val isRead: Boolean = false
)

data class AdminReport(
    val id: String,
    val reporter: User,
    val reportedUser: User,
    val reason: String,
    val contextNote: String,
    val status: String = "PENDING", // PENDING, RESOLVED, DISMISSED
    val timestamp: String
)

data class VerificationRequest(
    val id: String,
    val user: User,
    val documentType: String,
    val documentNumberMasked: String,
    val submittedDate: String,
    val status: VerificationStatus
)

data class SecurityAuditLog(
    val id: String,
    val action: String,
    val target: String,
    val ipMasked: String,
    val timestamp: String
)
