package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.LuxuryBottomNav
import com.example.ui.components.LuxuryTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.util.Strings
import com.example.viewmodel.GirlsTalkViewModel
import com.example.viewmodel.ScreenDestination
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: GirlsTalkViewModel = viewModel()
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            GirlsTalkTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DeepBlack
                ) {
                    GirlsTalkApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun GirlsTalkApp(
    viewModel: GirlsTalkViewModel
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val lang = state.language

    // Handle Hardware/Gesture Back Navigation
    BackHandler(enabled = true) {
        when (state.currentScreen) {
            ScreenDestination.MAIN_CONTAINER -> {
                if (state.selectedTab != "home") {
                    viewModel.selectTab("home")
                }
            }
            ScreenDestination.WELCOME, ScreenDestination.SPLASH -> {
                // Exit app or stay on welcome
            }
            ScreenDestination.LOGIN, ScreenDestination.REGISTER -> {
                viewModel.navigateTo(ScreenDestination.WELCOME)
            }
            ScreenDestination.OTP_VERIFICATION -> {
                viewModel.navigateTo(ScreenDestination.REGISTER)
            }
            ScreenDestination.AGE_IDENTITY_VERIFICATION -> {
                viewModel.navigateTo(ScreenDestination.OTP_VERIFICATION)
            }
            ScreenDestination.PROFILE_SETUP -> {
                viewModel.navigateTo(ScreenDestination.AGE_IDENTITY_VERIFICATION)
            }
            ScreenDestination.AUDIO_CALL, ScreenDestination.VIDEO_CALL -> {
                viewModel.endCall()
            }
            else -> {
                viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (state.currentScreen) {
            ScreenDestination.SPLASH -> {
                SplashScreen(onTimeout = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) })
            }
            ScreenDestination.WELCOME -> {
                WelcomeScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.LOGIN -> {
                LoginScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.REGISTER -> {
                RegisterScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.OTP_VERIFICATION -> {
                OtpScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.AGE_IDENTITY_VERIFICATION -> {
                AgeIdentityVerificationScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.PROFILE_SETUP -> {
                ProfileSetupScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.CHAT_DETAIL -> {
                PrivateChatScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.GROUP_CHAT_DETAIL -> {
                GroupChatScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.AUDIO_CALL -> {
                AudioCallScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.VIDEO_CALL -> {
                VideoCallScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.NOTIFICATIONS -> {
                NotificationsScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.PRIVACY_SETTINGS -> {
                PrivacySettingsScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.SAFETY_CENTER -> {
                SafetyCenterScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.BLOCKED_USERS -> {
                BlockedUsersScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.REPORT_MEMBER -> {
                ReportMemberScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.ADMIN_DASHBOARD -> {
                AdminDashboardScreen(state = state, viewModel = viewModel)
            }
            ScreenDestination.MAIN_CONTAINER -> {
                Scaffold(
                    topBar = {
                        LuxuryTopBar(
                            currentScreenTitle = Strings.get("app_name", lang),
                            language = lang,
                            onLanguageToggle = { viewModel.toggleLanguage() },
                            onSosClick = { viewModel.navigateTo(ScreenDestination.SAFETY_CENTER) },
                            onNotificationsClick = { viewModel.navigateTo(ScreenDestination.NOTIFICATIONS) },
                            unreadNotificationCount = state.notifications.count { !it.isRead }
                        )
                    },
                    bottomBar = {
                        LuxuryBottomNav(
                            selectedTab = state.selectedTab,
                            onTabSelected = { tab -> viewModel.selectTab(tab) },
                            language = lang,
                            unreadMessagesCount = state.conversations.sumOf { it.unreadCount }
                        )
                    },
                    containerColor = DeepBlack
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (state.selectedTab) {
                            "home" -> HomeScreen(state = state, viewModel = viewModel)
                            "discover" -> DiscoverScreen(state = state, viewModel = viewModel)
                            "chats" -> ChatsScreen(state = state, viewModel = viewModel)
                            "communities" -> CommunitiesScreen(state = state, viewModel = viewModel)
                            "profile" -> ProfileScreen(state = state, viewModel = viewModel)
                        }
                    }
                }
            }
        }

        // Overlay: Incoming Call Dialog
        state.incomingCall?.let { call ->
            IncomingCallDialog(
                call = call,
                onAccept = { viewModel.acceptIncomingCall() },
                onReject = { viewModel.rejectIncomingCall() }
            )
        }

        // Floating Banner / Notification Toast
        state.bannerMessage?.let { message ->
            LaunchedEffect(message) {
                delay(3000)
                viewModel.clearBanner()
            }
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 16.dp, start = 20.dp, end = 20.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, GoldPrimary, RoundedCornerShape(12.dp)),
                color = CardSurfaceElevated,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "✨ $message",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    )
                }
            }
        }
    }
}
