package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SampleData
import com.example.model.*
import com.example.util.AppLanguage
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ScreenDestination {
    SPLASH,
    WELCOME,
    LOGIN,
    REGISTER,
    OTP_VERIFICATION,
    AGE_IDENTITY_VERIFICATION,
    PROFILE_SETUP,
    MAIN_CONTAINER,
    CHAT_DETAIL,
    GROUP_CHAT_DETAIL,
    AUDIO_CALL,
    VIDEO_CALL,
    NOTIFICATIONS,
    PRIVACY_SETTINGS,
    SAFETY_CENTER,
    ADMIN_DASHBOARD,
    BLOCKED_USERS,
    REPORT_MEMBER
}

data class UiState(
    val currentScreen: ScreenDestination = ScreenDestination.MAIN_CONTAINER,
    val selectedTab: String = "home",
    val language: AppLanguage = AppLanguage.ENGLISH,
    val currentUser: User = SampleData.currentMember,
    val isAuthenticated: Boolean = true,
    
    // Auth form state
    val phoneInput: String = "+880 1712-345678",
    val emailInput: String = "tasnim@girlstalk.private",
    val passwordInput: String = "LuxurySanctuary2026",
    val otpInput: String = "",
    val dobInput: String = "1997-04-12",
    val idTypeInput: String = "National ID / Smart Card",
    val idDocNumberInput: String = "NID-8821-4490-BD",
    val hasAcceptedVerificationConsent: Boolean = true,
    val isOtpLoading: Boolean = false,
    val otpCountdown: Int = 45,
    
    // Community & Members
    val members: List<User> = SampleData.sampleMembers,
    val searchQuery: String = "",
    val selectedCountryFilter: String = "All",
    val selectedInterestFilter: String = "All",
    
    // Messaging
    val conversations: List<Conversation> = SampleData.initialConversations,
    val activeConversation: Conversation? = SampleData.initialConversations[0],
    val activeChatMessages: List<ChatMessage> = SampleData.initialChatMessages,
    val isRecordingVoice: Boolean = false,
    val voiceRecordSec: Int = 0,
    
    // Groups
    val communityGroups: List<CommunityGroup> = SampleData.initialGroups,
    val activeGroup: CommunityGroup? = null,
    
    // Posts
    val communityPosts: List<CommunityPost> = SampleData.initialPosts,
    
    // Calling
    val activeCall: CallSession? = null,
    val incomingCall: CallSession? = null,
    
    // Notifications & Safety
    val notifications: List<NotificationItem> = SampleData.initialNotifications,
    val blockedUsers: List<User> = emptyList(),
    val reportingTargetUser: User? = null,
    
    // Admin
    val verificationRequests: List<VerificationRequest> = SampleData.initialVerificationRequests,
    val adminReports: List<AdminReport> = SampleData.initialAdminReports,
    val securityLogs: List<SecurityAuditLog> = SampleData.initialSecurityLogs,
    val bannerMessage: String? = null
)

class GirlsTalkViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        // Start on Main Container by default so user can immediately experience the sanctuary!
        // Also provide easy demo switch to Splash/Welcome/Login/Verification.
    }

    fun toggleLanguage() {
        _uiState.update {
            val next = if (it.language == AppLanguage.ENGLISH) AppLanguage.BENGALI else AppLanguage.ENGLISH
            it.copy(language = next)
        }
    }

    fun setLanguage(language: AppLanguage) {
        _uiState.update { it.copy(language = language) }
    }

    fun navigateTo(screen: ScreenDestination) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun selectTab(tab: String) {
        _uiState.update {
            it.copy(
                selectedTab = tab,
                currentScreen = ScreenDestination.MAIN_CONTAINER
            )
        }
    }

    // --- Authentication & Verification Flow ---

    fun onPhoneChange(phone: String) {
        _uiState.update { it.copy(phoneInput = phone) }
    }

    fun onEmailChange(email: String) {
        _uiState.update { it.copy(emailInput = email) }
    }

    fun onPasswordChange(pass: String) {
        _uiState.update { it.copy(passwordInput = pass) }
    }

    fun onOtpChange(otp: String) {
        if (otp.length <= 6) {
            _uiState.update { it.copy(otpInput = otp) }
        }
    }

    fun onDobChange(dob: String) {
        _uiState.update { it.copy(dobInput = dob) }
    }

    fun onIdTypeChange(type: String) {
        _uiState.update { it.copy(idTypeInput = type) }
    }

    fun onIdDocNumberChange(number: String) {
        _uiState.update { it.copy(idDocNumberInput = number) }
    }

    fun toggleVerificationConsent(accepted: Boolean) {
        _uiState.update { it.copy(hasAcceptedVerificationConsent = accepted) }
    }

    fun startRegistration() {
        _uiState.update { it.copy(currentScreen = ScreenDestination.OTP_VERIFICATION, isOtpLoading = true) }
        viewModelScope.launch {
            delay(800)
            _uiState.update { it.copy(isOtpLoading = false, otpInput = "592814") }
        }
    }

    fun verifyOtp() {
        _uiState.update { it.copy(currentScreen = ScreenDestination.AGE_IDENTITY_VERIFICATION) }
    }

    fun submitIdentityVerification() {
        // Enforce 18+ check and verification creation
        _uiState.update {
            val updatedUser = it.currentUser.copy(
                isVerified = true,
                verificationStatus = VerificationStatus.VERIFIED,
                verificationDocRef = "${it.idTypeInput.take(4).uppercase()}-***-ENC"
            )
            it.copy(
                currentUser = updatedUser,
                currentScreen = ScreenDestination.PROFILE_SETUP
            )
        }
    }

    fun completeProfileSetup(name: String, city: String, country: String, bio: String) {
        _uiState.update {
            val updated = it.currentUser.copy(
                name = name.ifBlank { it.currentUser.name },
                city = city.ifBlank { it.currentUser.city },
                country = country.ifBlank { it.currentUser.country },
                bio = bio.ifBlank { it.currentUser.bio }
            )
            it.copy(
                currentUser = updated,
                isAuthenticated = true,
                currentScreen = ScreenDestination.MAIN_CONTAINER,
                selectedTab = "home"
            )
        }
    }

    fun switchAccountRole(toAdmin: Boolean) {
        _uiState.update {
            if (toAdmin) {
                it.copy(
                    currentUser = SampleData.adminUser,
                    isAuthenticated = true,
                    currentScreen = ScreenDestination.ADMIN_DASHBOARD
                )
            } else {
                it.copy(
                    currentUser = SampleData.currentMember,
                    isAuthenticated = true,
                    currentScreen = ScreenDestination.MAIN_CONTAINER,
                    selectedTab = "home"
                )
            }
        }
    }

    fun logout() {
        _uiState.update {
            it.copy(
                isAuthenticated = false,
                currentScreen = ScreenDestination.WELCOME
            )
        }
    }

    // --- Discover & Members ---

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setCountryFilter(country: String) {
        _uiState.update { it.copy(selectedCountryFilter = country) }
    }

    fun setInterestFilter(interest: String) {
        _uiState.update { it.copy(selectedInterestFilter = interest) }
    }

    fun connectMember(targetUser: User) {
        _uiState.update {
            val updatedMembers = it.members.map { m ->
                if (m.id == targetUser.id) m.copy(isOnline = true) else m
            }
            it.copy(
                members = updatedMembers,
                bannerMessage = "Connection request accepted by ${targetUser.name}"
            )
        }
    }

    // --- Private Chat & Messaging ---

    fun openChat(conversation: Conversation) {
        _uiState.update {
            it.copy(
                activeConversation = conversation,
                currentScreen = ScreenDestination.CHAT_DETAIL
            )
        }
    }

    fun openChatWithMember(member: User) {
        // Find existing or create new conversation
        val existing = _uiState.value.conversations.find { it.participant.id == member.id }
        if (existing != null) {
            openChat(existing)
        } else {
            val newConv = Conversation(
                id = "conv_${member.id}",
                participant = member,
                lastMessage = ChatMessage(
                    id = "msg_${System.currentTimeMillis()}",
                    conversationId = "conv_${member.id}",
                    senderId = member.id,
                    senderName = member.name,
                    text = "Connected in the GIRLS TALK Sanctuary.",
                    timestamp = "Just now"
                )
            )
            _uiState.update {
                it.copy(
                    conversations = listOf(newConv) + it.conversations,
                    activeConversation = newConv,
                    activeChatMessages = listOf(newConv.lastMessage),
                    currentScreen = ScreenDestination.CHAT_DETAIL
                )
            }
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        val conv = _uiState.value.activeConversation ?: return
        val newMsg = ChatMessage(
            id = "msg_${System.currentTimeMillis()}",
            conversationId = conv.id,
            senderId = _uiState.value.currentUser.id,
            senderName = _uiState.value.currentUser.name,
            text = text.trim(),
            type = MessageType.TEXT,
            timestamp = "Just now",
            isRead = false,
            isDelivered = true
        )

        _uiState.update {
            val updatedMessages = it.activeChatMessages + newMsg
            val updatedConversations = it.conversations.map { c ->
                if (c.id == conv.id) c.copy(lastMessage = newMsg) else c
            }
            it.copy(
                activeChatMessages = updatedMessages,
                conversations = updatedConversations
            )
        }

        // Simulate reply after 1.5 seconds from verified peer
        viewModelScope.launch {
            delay(1500)
            val replyMsg = ChatMessage(
                id = "msg_${System.currentTimeMillis()}",
                conversationId = conv.id,
                senderId = conv.participant.id,
                senderName = conv.participant.name,
                text = "Thank you so much! Always appreciate our authentic, safe conversations here.",
                type = MessageType.TEXT,
                timestamp = "Just now",
                isRead = true
            )
            _uiState.update {
                it.copy(
                    activeChatMessages = it.activeChatMessages + replyMsg,
                    conversations = it.conversations.map { c ->
                        if (c.id == conv.id) c.copy(lastMessage = replyMsg) else c
                    }
                )
            }
        }
    }

    fun startVoiceRecording() {
        _uiState.update { it.copy(isRecordingVoice = true, voiceRecordSec = 0) }
        viewModelScope.launch {
            while (_uiState.value.isRecordingVoice) {
                delay(1000)
                _uiState.update { it.copy(voiceRecordSec = it.voiceRecordSec + 1) }
            }
        }
    }

    fun stopAndSendVoiceRecording() {
        val duration = _uiState.value.voiceRecordSec.coerceAtLeast(2)
        _uiState.update { it.copy(isRecordingVoice = false, voiceRecordSec = 0) }
        val conv = _uiState.value.activeConversation ?: return
        val voiceMsg = ChatMessage(
            id = "msg_v_${System.currentTimeMillis()}",
            conversationId = conv.id,
            senderId = _uiState.value.currentUser.id,
            senderName = _uiState.value.currentUser.name,
            text = "Voice message (0:${if (duration < 10) "0$duration" else "$duration"})",
            type = MessageType.VOICE,
            voiceDurationSec = duration,
            timestamp = "Just now",
            isRead = false
        )
        _uiState.update {
            it.copy(
                activeChatMessages = it.activeChatMessages + voiceMsg,
                conversations = it.conversations.map { c ->
                    if (c.id == conv.id) c.copy(lastMessage = voiceMsg) else c
                }
            )
        }
    }

    fun sendImageAttachment() {
        val conv = _uiState.value.activeConversation ?: return
        val imgMsg = ChatMessage(
            id = "msg_img_${System.currentTimeMillis()}",
            conversationId = conv.id,
            senderId = _uiState.value.currentUser.id,
            senderName = _uiState.value.currentUser.name,
            text = "Photo shared in encrypted chat",
            type = MessageType.IMAGE,
            mediaUrl = "sample_photo",
            timestamp = "Just now",
            isRead = false
        )
        _uiState.update {
            it.copy(
                activeChatMessages = it.activeChatMessages + imgMsg,
                conversations = it.conversations.map { c ->
                    if (c.id == conv.id) c.copy(lastMessage = imgMsg) else c
                }
            )
        }
    }

    fun deleteMessage(messageId: String) {
        _uiState.update {
            it.copy(
                activeChatMessages = it.activeChatMessages.filterNot { m -> m.id == messageId }
            )
        }
    }

    // --- Audio & Video Calling ---

    fun startCall(peerUser: User, isVideo: Boolean) {
        val session = CallSession(
            id = "call_${System.currentTimeMillis()}",
            peerUser = peerUser,
            isVideo = isVideo,
            status = CallStatus.ACTIVE,
            durationSeconds = 0
        )
        _uiState.update {
            it.copy(
                activeCall = session,
                currentScreen = if (isVideo) ScreenDestination.VIDEO_CALL else ScreenDestination.AUDIO_CALL
            )
        }

        viewModelScope.launch {
            while (_uiState.value.activeCall != null && _uiState.value.activeCall?.status == CallStatus.ACTIVE) {
                delay(1000)
                _uiState.update { current ->
                    current.copy(
                        activeCall = current.activeCall?.copy(
                            durationSeconds = (current.activeCall?.durationSeconds ?: 0) + 1
                        )
                    )
                }
            }
        }
    }

    fun toggleMuteCall() {
        _uiState.update {
            it.copy(
                activeCall = it.activeCall?.copy(isMuted = !(it.activeCall.isMuted))
            )
        }
    }

    fun toggleSpeakerCall() {
        _uiState.update {
            it.copy(
                activeCall = it.activeCall?.copy(isSpeakerOn = !(it.activeCall.isSpeakerOn))
            )
        }
    }

    fun toggleCameraCall() {
        _uiState.update {
            it.copy(
                activeCall = it.activeCall?.copy(isCameraOff = !(it.activeCall.isCameraOff))
            )
        }
    }

    fun switchCameraFacing() {
        _uiState.update {
            it.copy(
                activeCall = it.activeCall?.copy(isFrontCamera = !(it.activeCall.isFrontCamera))
            )
        }
    }

    fun endCall() {
        _uiState.update {
            it.copy(
                activeCall = null,
                incomingCall = null,
                currentScreen = ScreenDestination.MAIN_CONTAINER
            )
        }
    }

    fun triggerIncomingCallDemo(isVideo: Boolean) {
        val caller = SampleData.sampleMembers[0]
        val session = CallSession(
            id = "inc_${System.currentTimeMillis()}",
            peerUser = caller,
            isVideo = isVideo,
            status = CallStatus.INCOMING
        )
        _uiState.update { it.copy(incomingCall = session) }
    }

    fun acceptIncomingCall() {
        val inc = _uiState.value.incomingCall ?: return
        startCall(inc.peerUser, inc.isVideo)
        _uiState.update { it.copy(incomingCall = null) }
    }

    fun rejectIncomingCall() {
        _uiState.update { it.copy(incomingCall = null) }
    }

    // --- Communities & Posts ---

    fun togglePostLike(postId: String) {
        _uiState.update {
            val updated = it.communityPosts.map { p ->
                if (p.id == postId) {
                    val newLiked = !p.isLiked
                    p.copy(
                        isLiked = newLiked,
                        likesCount = if (newLiked) p.likesCount + 1 else (p.likesCount - 1).coerceAtLeast(0)
                    )
                } else p
            }
            it.copy(communityPosts = updated)
        }
    }

    fun addPostComment(postId: String, text: String) {
        if (text.isBlank()) return
        val newComment = PostComment(
            id = "c_${System.currentTimeMillis()}",
            author = _uiState.value.currentUser,
            text = text.trim(),
            timestamp = "Just now"
        )
        _uiState.update {
            val updated = it.communityPosts.map { p ->
                if (p.id == postId) {
                    p.copy(
                        comments = p.comments + newComment,
                        commentsCount = p.commentsCount + 1
                    )
                } else p
            }
            it.copy(communityPosts = updated)
        }
    }

    fun createPost(content: String, category: String) {
        if (content.isBlank()) return
        val newPost = CommunityPost(
            id = "post_${System.currentTimeMillis()}",
            author = _uiState.value.currentUser,
            content = content.trim(),
            category = category,
            likesCount = 1,
            commentsCount = 0,
            isLiked = true,
            timestamp = "Just now",
            comments = emptyList()
        )
        _uiState.update {
            it.copy(
                communityPosts = listOf(newPost) + it.communityPosts,
                bannerMessage = "Post published to community"
            )
        }
    }

    fun toggleGroupJoin(groupId: String) {
        _uiState.update {
            val updated = it.communityGroups.map { g ->
                if (g.id == groupId) {
                    val joined = !g.isJoined
                    g.copy(
                        isJoined = joined,
                        memberCount = if (joined) g.memberCount + 1 else g.memberCount - 1
                    )
                } else g
            }
            it.copy(communityGroups = updated)
        }
    }

    fun openGroupChat(group: CommunityGroup) {
        _uiState.update {
            it.copy(
                activeGroup = group,
                currentScreen = ScreenDestination.GROUP_CHAT_DETAIL
            )
        }
    }

    // --- Safety, Reporting & Blocking ---

    fun initiateReport(user: User) {
        _uiState.update {
            it.copy(
                reportingTargetUser = user,
                currentScreen = ScreenDestination.REPORT_MEMBER
            )
        }
    }

    fun submitReport(reason: String, notes: String) {
        val target = _uiState.value.reportingTargetUser ?: return
        val report = AdminReport(
            id = "rep_${System.currentTimeMillis()}",
            reporter = _uiState.value.currentUser,
            reportedUser = target,
            reason = reason,
            contextNote = notes,
            status = "PENDING",
            timestamp = "Just now"
        )
        _uiState.update {
            it.copy(
                adminReports = listOf(report) + it.adminReports,
                currentScreen = ScreenDestination.MAIN_CONTAINER,
                bannerMessage = "Report submitted to Safety Moderation Team"
            )
        }
    }

    fun blockUser(user: User) {
        _uiState.update {
            it.copy(
                blockedUsers = it.blockedUsers + user,
                conversations = it.conversations.filterNot { c -> c.participant.id == user.id },
                currentScreen = ScreenDestination.MAIN_CONTAINER,
                bannerMessage = "${user.name} has been blocked"
            )
        }
    }

    fun unblockUser(user: User) {
        _uiState.update {
            it.copy(
                blockedUsers = it.blockedUsers.filterNot { u -> u.id == user.id },
                bannerMessage = "${user.name} has been unblocked"
            )
        }
    }

    // --- Privacy Settings ---

    fun updatePrivacySettings(settings: PrivacySettings) {
        _uiState.update {
            it.copy(
                currentUser = it.currentUser.copy(privacySettings = settings),
                bannerMessage = "Privacy settings updated"
            )
        }
    }

    // --- Admin Dashboard Actions ---

    fun approveVerification(reqId: String) {
        _uiState.update { state ->
            val updatedReqs = state.verificationRequests.map { req ->
                if (req.id == reqId) req.copy(status = VerificationStatus.VERIFIED) else req
            }
            val log = SecurityAuditLog(
                id = "log_${System.currentTimeMillis()}",
                action = "Admin Granted 18+ Verification",
                target = "Request #$reqId",
                ipMasked = "Admin Session",
                timestamp = "Just now"
            )
            state.copy(
                verificationRequests = updatedReqs,
                securityLogs = listOf(log) + state.securityLogs,
                bannerMessage = "Verification approved"
            )
        }
    }

    fun rejectVerification(reqId: String) {
        _uiState.update { state ->
            val updatedReqs = state.verificationRequests.map { req ->
                if (req.id == reqId) req.copy(status = VerificationStatus.REJECTED) else req
            }
            state.copy(
                verificationRequests = updatedReqs,
                bannerMessage = "Verification rejected (Notice sent to applicant)"
            )
        }
    }

    fun resolveReport(reportId: String, suspendAccount: Boolean) {
        _uiState.update { state ->
            val updated = state.adminReports.map { r ->
                if (r.id == reportId) r.copy(status = if (suspendAccount) "SUSPENDED" else "DISMISSED") else r
            }
            val log = SecurityAuditLog(
                id = "log_${System.currentTimeMillis()}",
                action = if (suspendAccount) "Account Suspended by Admin" else "Report Dismissed",
                target = "Report #$reportId",
                ipMasked = "Admin Session",
                timestamp = "Just now"
            )
            state.copy(
                adminReports = updated,
                securityLogs = listOf(log) + state.securityLogs,
                bannerMessage = if (suspendAccount) "User account suspended" else "Report dismissed"
            )
        }
    }

    fun clearBanner() {
        _uiState.update { it.copy(bannerMessage = null) }
    }
}
