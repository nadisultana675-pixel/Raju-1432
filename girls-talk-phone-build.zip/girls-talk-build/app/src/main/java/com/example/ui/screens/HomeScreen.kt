package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CommunityPost
import com.example.model.UserRole
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.Strings
import com.example.viewmodel.GirlsTalkViewModel
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.UiState

@Composable
fun HomeScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    var showCreatePostDialog by remember { mutableStateOf(false) }
    var selectedPostForComments by remember { mutableStateOf<CommunityPost?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Luxury Penthouse Featured Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .border(1.dp, GoldBorder, RoundedCornerShape(18.dp)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_luxury),
                        contentDescription = "GIRLS TALK Sanctuary",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, DeepBlack.copy(alpha = 0.85f))
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            VerifiedBadge(status = state.currentUser.verificationStatus)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "PRIVATE SANCTUARY",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = GoldLight,
                                    letterSpacing = 1.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = Strings.get("tagline", lang),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = PlayfairFontFamily,
                                color = TextWhite,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Stories / Active Verified Members Row
        item {
            Column {
                Text(
                    text = "ACTIVE SISTERS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(state.members) { member ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { viewModel.openChatWithMember(member) }
                                .padding(4.dp)
                        ) {
                            AvatarWithStatus(user = member, size = 56.dp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = member.name.split(" ").firstOrNull() ?: member.name,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextLightGrey,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }
        }

        // Quick Post Creator Trigger Card
        item {
            GoldCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showCreatePostDialog = true }
                    .testTag("create_post_card"),
                borderWidth = 1.dp,
                borderColor = GoldBorder,
                backgroundColor = CardSurface
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AvatarWithStatus(user = state.currentUser, size = 40.dp, showOnlineStatus = false)
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .clip(RoundedCornerShape(21.dp))
                            .background(CharcoalBg)
                            .border(1.dp, GoldBorder, RoundedCornerShape(21.dp))
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = Strings.get("create_post", lang),
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    IconButton(
                        onClick = { showCreatePostDialog = true },
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color(0x22D4AF37), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Create Post",
                            tint = GoldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Feed Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = Strings.get("community_feed", lang),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = PlayfairFontFamily,
                        color = GoldLight,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "All Verified",
                    style = MaterialTheme.typography.bodySmall.copy(color = GoldPrimary)
                )
            }
        }

        // Community Feed Posts
        items(state.communityPosts) { post ->
            GoldCard(
                modifier = Modifier.fillMaxWidth(),
                borderWidth = 0.5.dp,
                borderColor = GoldBorder,
                backgroundColor = CardSurface
            ) {
                // Post Author Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewModel.openChatWithMember(post.author) }
                    ) {
                        AvatarWithStatus(user = post.author, size = 42.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = post.author.name,
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                VerifiedBadge(status = post.author.verificationStatus, compact = true)
                            }
                            Text(
                                text = "${post.author.city}, ${post.author.country} • ${post.timestamp}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x22D4AF37)),
                        color = Color.Transparent
                    ) {
                        Text(
                            text = post.category,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = GoldPrimary,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Post Content
                Text(
                    text = post.content,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextWhite,
                        lineHeight = 22.sp
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                HorizontalDivider(color = GoldBorder.copy(alpha = 0.3f))

                // Actions: Like, Comment, Share
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Like button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewModel.togglePostLike(post.id) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (post.isLiked) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (post.isLiked) DangerRed else GoldLight,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${post.likesCount}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (post.isLiked) DangerRed else TextLightGrey,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    // Comments button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedPostForComments = post }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ChatBubbleOutline,
                            contentDescription = "Comment",
                            tint = GoldLight,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${post.commentsCount}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextLightGrey)
                        )
                    }

                    // Direct Message button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewModel.openChatWithMember(post.author) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Message Sister",
                            tint = GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Connect",
                            style = MaterialTheme.typography.labelSmall.copy(color = GoldPrimary)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Create Post Dialog
    if (showCreatePostDialog) {
        var postText by remember { mutableStateOf("") }
        var selectedCategory by remember { mutableStateOf("Empowerment & Advice") }
        val categories = listOf("Empowerment & Advice", "Wellness & Health", "Entrepreneurship", "Arts & Culture")

        AlertDialog(
            onDismissRequest = { showCreatePostDialog = false },
            containerColor = CardSurface,
            title = {
                Text(
                    text = "Share in Sanctuary",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = PlayfairFontFamily,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Category",
                        style = MaterialTheme.typography.labelSmall.copy(color = GoldLight)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(categories) { cat ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        1.dp,
                                        if (selectedCategory == cat) GoldPrimary else GoldBorder,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedCategory = cat },
                                color = if (selectedCategory == cat) Color(0x33D4AF37) else CharcoalBg
                            ) {
                                Text(
                                    text = cat,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = if (selectedCategory == cat) GoldLight else TextLightGrey
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = postText,
                        onValueChange = { postText = it },
                        placeholder = { Text(Strings.get("create_post", lang), color = TextMuted) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GoldBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedContainerColor = CharcoalBg,
                            unfocusedContainerColor = CharcoalBg
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                GoldButton(
                    text = Strings.get("post_btn", lang),
                    onClick = {
                        viewModel.createPost(postText, selectedCategory)
                        showCreatePostDialog = false
                    },
                    enabled = postText.isNotBlank()
                )
            },
            dismissButton = {
                TextButton(onClick = { showCreatePostDialog = false }) {
                    Text("Cancel", color = TextLightGrey)
                }
            }
        )
    }

    // Comments Sheet / Dialog
    selectedPostForComments?.let { post ->
        var commentInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { selectedPostForComments = null },
            containerColor = CardSurface,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Discussion (${post.comments.size})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = PlayfairFontFamily,
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(post.comments) { comment ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                color = CharcoalBg
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = comment.author.name,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = GoldLight,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "• ${comment.timestamp}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = TextMuted,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = comment.text,
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextWhite)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = commentInput,
                            onValueChange = { commentInput = it },
                            placeholder = { Text("Add comment...", color = TextMuted, fontSize = 12.sp) },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = GoldBorder,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite,
                                focusedContainerColor = CharcoalBg,
                                unfocusedContainerColor = CharcoalBg
                            ),
                            shape = RoundedCornerShape(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                viewModel.addPostComment(post.id, commentInput)
                                commentInput = ""
                            },
                            enabled = commentInput.isNotBlank(),
                            modifier = Modifier
                                .size(40.dp)
                                .background(GoldPrimary, CircleShape)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = DeepBlack, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedPostForComments = null }) {
                    Text("Close", color = GoldLight)
                }
            }
        )
    }
}
