package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val LuxuryDarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = DeepBlack,
    primaryContainer = GoldDark,
    onPrimaryContainer = GoldLight,
    secondary = GoldLight,
    onSecondary = DeepBlack,
    tertiary = GoldAccent,
    background = DeepBlack,
    onBackground = TextWhite,
    surface = CharcoalBg,
    onSurface = TextWhite,
    surfaceVariant = CardSurface,
    onSurfaceVariant = TextLightGrey,
    outline = GoldBorder,
    error = DangerRed
)

@Composable
fun GirlsTalkTheme(
    content: @Composable () -> Unit
) {
    // Default to the luxury dark theme as specified in the brief
    MaterialTheme(
        colorScheme = LuxuryDarkColorScheme,
        typography = AppTypography,
        content = content
    )
}
