package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CallSession
import com.example.model.CallStatus
import com.example.ui.components.AvatarWithStatus
import com.example.ui.components.VerifiedBadge
import com.example.ui.theme.*
import com.example.util.Strings
import com.example.viewmodel.GirlsTalkViewModel
import com.example.viewmodel.UiState

@Composable
fun AudioCallScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val call = state.activeCall ?: return
    val peer = call.peerUser
    val lang = state.language

    // Pulsing animation for luxury gold glowing ring
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val durationMin = call.durationSeconds / 60
    val durationSec = call.durationSeconds % 60
    val durationFormatted = "%02d:%02d".format(durationMin, durationSec)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(DeepBlack, CharcoalBg, DeepBlack)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header: Security indicator
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    modifier = Modifier
                        .background(Color(0x26D4AF37), RoundedCornerShape(12.dp))
                        .border(1.dp, GoldBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Encrypted",
                        tint = GoldPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "End-to-End Encrypted Audio Call",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = GoldLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = peer.name,
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = PlayfairFontFamily,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    VerifiedBadge(status = peer.verificationStatus)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "18+ Verified Sister",
                        style = MaterialTheme.typography.bodySmall.copy(color = GoldLight)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = durationFormatted,
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = GoldAccent,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
            }

            // Glowing Profile Avatar Centerpiece
            Box(
                contentAlignment = Alignment.Center
            ) {
                // Outer glowing pulse circle
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(Color(0x1AD4AF37))
                        .border(1.dp, GoldBorder, CircleShape)
                )
                // Secondary glow
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .clip(CircleShape)
                        .background(Color(0x2FD4AF37))
                        .border(1.5.dp, GoldPrimary.copy(alpha = 0.5f), CircleShape)
                )
                // Center Avatar
                AvatarWithStatus(user = peer, size = 120.dp, showOnlineStatus = false)
            }

            // Controls Bar
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Mute button
                    IconButton(
                        onClick = { viewModel.toggleMuteCall() },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (call.isMuted) Color(0x66E53935) else CardSurface)
                            .border(1.dp, if (call.isMuted) DangerRed else GoldBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (call.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Mute",
                            tint = if (call.isMuted) DangerRed else GoldLight,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // End call button
                    IconButton(
                        onClick = { viewModel.endCall() },
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(DangerRed)
                            .testTag("end_call_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "End Call",
                            tint = TextWhite,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // Speaker button
                    IconButton(
                        onClick = { viewModel.toggleSpeakerCall() },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (call.isSpeakerOn) Color(0x33D4AF37) else CardSurface)
                            .border(1.dp, if (call.isSpeakerOn) GoldPrimary else GoldBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (call.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                            contentDescription = "Speaker",
                            tint = if (call.isSpeakerOn) GoldPrimary else TextLightGrey,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "GIRLS TALK Sanctuary Audio Guard Active",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                )
            }
        }
    }
}

@Composable
fun VideoCallScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val call = state.activeCall ?: return
    val peer = call.peerUser
    val durationMin = call.durationSeconds / 60
    val durationSec = call.durationSeconds % 60
    val durationFormatted = "%02d:%02d".format(durationMin, durationSec)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        // Fullscreen simulated remote camera view
        if (!call.isCameraOff) {
            Image(
                painter = painterResource(id = R.drawable.img_avatar_sample),
                contentDescription = "Peer video feed",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(CharcoalBg),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.VideocamOff,
                        contentDescription = "Camera Off",
                        tint = GoldLight,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "${peer.name}'s camera is off",
                        style = MaterialTheme.typography.bodyLarge.copy(color = TextLightGrey)
                    )
                }
            }
        }

        // Dark gradient overlays for readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(DeepBlack.copy(alpha = 0.7f), Color.Transparent, DeepBlack.copy(alpha = 0.85f))
                    )
                )
        )

        // Top Bar info
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AvatarWithStatus(user = peer, size = 38.dp, showOnlineStatus = false)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = peer.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Encrypted • $durationFormatted",
                                style = MaterialTheme.typography.bodySmall.copy(color = GoldLight, fontSize = 11.sp)
                            )
                        }
                    }
                }

                VerifiedBadge(status = peer.verificationStatus)
            }
        }

        // Picture-in-Picture Local Self Preview
        Surface(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 80.dp, end = 16.dp)
                .size(width = 100.dp, height = 140.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.5.dp, GoldPrimary, RoundedCornerShape(12.dp)),
            color = CharcoalBg
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_girls_talk),
                    contentDescription = "My preview",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Text(
                    text = "You",
                    color = GoldLight,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .background(DeepBlack.copy(alpha = 0.7f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        // Bottom Controls Bar
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Switch Camera
                IconButton(
                    onClick = { viewModel.switchCameraFacing() },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(CardSurface)
                        .border(1.dp, GoldBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.FlipCameraAndroid,
                        contentDescription = "Flip camera",
                        tint = GoldLight,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Camera toggle
                IconButton(
                    onClick = { viewModel.toggleCameraCall() },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(if (call.isCameraOff) Color(0x66E53935) else CardSurface)
                        .border(1.dp, if (call.isCameraOff) DangerRed else GoldBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = if (call.isCameraOff) Icons.Default.VideocamOff else Icons.Default.Videocam,
                        contentDescription = "Camera Toggle",
                        tint = if (call.isCameraOff) DangerRed else GoldLight,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Mute microphone
                IconButton(
                    onClick = { viewModel.toggleMuteCall() },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(if (call.isMuted) Color(0x66E53935) else CardSurface)
                        .border(1.dp, if (call.isMuted) DangerRed else GoldBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = if (call.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mic Toggle",
                        tint = if (call.isMuted) DangerRed else GoldLight,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // End call
                IconButton(
                    onClick = { viewModel.endCall() },
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(DangerRed)
                        .testTag("end_video_call_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = TextWhite,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun IncomingCallDialog(
    call: CallSession,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onReject,
        containerColor = CardSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (call.isVideo) Icons.Default.Videocam else Icons.Default.Call,
                    contentDescription = null,
                    tint = GoldPrimary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (call.isVideo) "Incoming Video Call" else "Incoming Audio Call",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = PlayfairFontFamily,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(10.dp))
                AvatarWithStatus(user = call.peerUser, size = 70.dp, showOnlineStatus = false)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = call.peerUser.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${call.peerUser.city}, ${call.peerUser.country}",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextLightGrey)
                )
                Spacer(modifier = Modifier.height(6.dp))
                VerifiedBadge(status = call.peerUser.verificationStatus)
            }
        },
        confirmButton = {
            Button(
                onClick = onAccept,
                colors = ButtonDefaults.buttonColors(containerColor = CallGreen),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Icon(Icons.Default.Call, contentDescription = "Accept", tint = TextWhite)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Accept", color = TextWhite, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onReject,
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                shape = RoundedCornerShape(20.dp)
            ) {
                Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = TextWhite)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Decline", color = TextWhite, fontWeight = FontWeight.Bold)
            }
        }
    )
}
