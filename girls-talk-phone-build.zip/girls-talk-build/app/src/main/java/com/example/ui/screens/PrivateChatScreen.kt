package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ChatMessage
import com.example.model.MessageType
import com.example.model.User
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.Strings
import com.example.viewmodel.GirlsTalkViewModel
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.UiState
import kotlinx.coroutines.launch

@Composable
fun PrivateChatScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    val conversation = state.activeConversation ?: return
    val peer = conversation.participant
    var textInput by remember { mutableStateOf("") }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showBlockConfirmDialog by remember { mutableStateOf(false) }
    var selectedMessageForAction by remember { mutableStateOf<ChatMessage?>(null) }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(state.activeChatMessages.size) {
        if (state.activeChatMessages.isNotEmpty()) {
            listState.animateScrollToItem(state.activeChatMessages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = DeepBlack,
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .border(0.5.dp, GoldBorder, RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
                    }

                    AvatarWithStatus(user = peer, size = 42.dp)

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = peer.name,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite,
                                    fontSize = 15.sp
                                )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            VerifiedBadge(status = peer.verificationStatus, compact = true)
                        }
                        Text(
                            text = if (peer.isOnline) "Active in Sanctuary" else peer.lastSeen,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (peer.isOnline) StatusOnline else TextMuted,
                                fontSize = 11.sp
                            )
                        )
                    }

                    // Direct Call Actions
                    IconButton(
                        onClick = { viewModel.startCall(peer, isVideo = false) },
                        modifier = Modifier
                            .size(36.dp)
                            .background(CardSurface, CircleShape)
                            .border(1.dp, GoldBorder, CircleShape)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Audio Call", tint = GoldPrimary, modifier = Modifier.size(18.dp))
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = { viewModel.startCall(peer, isVideo = true) },
                        modifier = Modifier
                            .size(36.dp)
                            .background(CardSurface, CircleShape)
                            .border(1.dp, GoldBorder, CircleShape)
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = GoldPrimary, modifier = Modifier.size(18.dp))
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Box {
                        IconButton(onClick = { showMoreMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More", tint = GoldLight)
                        }

                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false },
                            modifier = Modifier.background(CardSurface)
                        ) {
                            DropdownMenuItem(
                                text = { Text(Strings.get("report_user", lang), color = TextWhite) },
                                onClick = {
                                    showMoreMenu = false
                                    viewModel.initiateReport(peer)
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Flag, contentDescription = null, tint = DangerRed)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(Strings.get("block_user", lang), color = DangerRed) },
                                onClick = {
                                    showMoreMenu = false
                                    showBlockConfirmDialog = true
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Block, contentDescription = null, tint = DangerRed)
                                }
                            )
                        }
                    }
                }
            }
        },
        containerColor = DeepBlack
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // E2E Security notification banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x14D4AF37))
                    .padding(vertical = 6.dp, horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "End-to-End Encrypted Private Channel • 18+ Verified Women Only",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = GoldLight,
                        fontSize = 10.sp
                    )
                )
            }

            // Messages LazyColumn
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                }

                items(state.activeChatMessages) { msg ->
                    val isMe = msg.senderId == state.currentUser.id
                    ChatBubble(
                        message = msg,
                        isMe = isMe,
                        onLongClick = { selectedMessageForAction = msg }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            // Voice Recording Bar (if recording)
            AnimatedVisibility(visible = state.isRecordingVoice) {
                Surface(
                    color = Color(0x33D4AF37),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(DangerRed)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Recording audio... 0:${if (state.voiceRecordSec < 10) "0${state.voiceRecordSec}" else "${state.voiceRecordSec}"}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        GoldButton(
                            text = "Send Note",
                            onClick = { viewModel.stopAndSendVoiceRecording() },
                            modifier = Modifier.height(36.dp)
                        )
                    }
                }
            }

            // Input Bar
            Surface(
                color = CharcoalBg,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .border(0.5.dp, GoldBorder, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Photo share button
                    IconButton(
                        onClick = { viewModel.sendImageAttachment() },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Attach photo",
                            tint = GoldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Voice note toggle button
                    IconButton(
                        onClick = {
                            if (state.isRecordingVoice) {
                                viewModel.stopAndSendVoiceRecording()
                            } else {
                                viewModel.startVoiceRecording()
                            }
                        },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = if (state.isRecordingVoice) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Voice Note",
                            tint = if (state.isRecordingVoice) DangerRed else GoldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Text Field
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text(Strings.get("type_message", lang), color = TextMuted, fontSize = 13.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_message_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GoldBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedContainerColor = CardSurface,
                            unfocusedContainerColor = CardSurface
                        ),
                        shape = RoundedCornerShape(22.dp),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Send Button
                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                            }
                        },
                        enabled = textInput.isNotBlank(),
                        modifier = Modifier
                            .size(44.dp)
                            .background(if (textInput.isNotBlank()) GoldPrimary else Color(0x33D4AF37), CircleShape)
                            .testTag("send_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = if (textInput.isNotBlank()) DeepBlack else TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }

    // Message Action Sheet (Delete)
    selectedMessageForAction?.let { msg ->
        AlertDialog(
            onDismissRequest = { selectedMessageForAction = null },
            containerColor = CardSurface,
            title = { Text("Message Options", color = GoldPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("Would you like to delete this message from the encrypted record?", color = TextLightGrey) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteMessage(msg.id)
                        selectedMessageForAction = null
                    }
                ) {
                    Text(Strings.get("delete_message", lang), color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedMessageForAction = null }) {
                    Text("Cancel", color = TextWhite)
                }
            }
        )
    }

    // Block Confirmation Dialog
    if (showBlockConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showBlockConfirmDialog = false },
            containerColor = CardSurface,
            title = { Text("Block ${peer.name}?", color = DangerRed, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "They will no longer be able to message you, call you, or view your community profile. You can unblock anytime from Settings.",
                    color = TextLightGrey
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.blockUser(peer)
                        showBlockConfirmDialog = false
                    }
                ) {
                    Text("Confirm Block", color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBlockConfirmDialog = false }) {
                    Text("Cancel", color = TextWhite)
                }
            }
        )
    }
}

@Composable
private fun ChatBubble(
    message: ChatMessage,
    isMe: Boolean,
    onLongClick: () -> Unit
) {
    var isPlayingVoice by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isMe) 16.dp else 4.dp,
                        bottomEnd = if (isMe) 4.dp else 16.dp
                    )
                )
                .border(
                    width = 1.dp,
                    color = if (isMe) GoldPrimary.copy(alpha = 0.5f) else GoldBorder.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(16.dp)
                )
                .clickable { onLongClick() },
            color = if (isMe) Color(0xFF282006) else CardSurface
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                when (message.type) {
                    MessageType.TEXT -> {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextWhite,
                                lineHeight = 20.sp
                            )
                        )
                    }
                    MessageType.VOICE -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { isPlayingVoice = !isPlayingVoice },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(GoldPrimary, CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isPlayingVoice) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play voice note",
                                    tint = DeepBlack,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                // Waveform simulation bars
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val barHeights = listOf(14, 22, 10, 26, 18, 12, 28, 16, 22, 12, 24, 18, 14, 20)
                                    barHeights.forEachIndexed { idx, height ->
                                        val active = isPlayingVoice && idx < 8
                                        Box(
                                            modifier = Modifier
                                                .width(3.dp)
                                                .height(height.dp)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(if (active) GoldAccent else GoldPrimary.copy(alpha = 0.6f))
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isPlayingVoice) "Playing 0:14 / 0:${message.voiceDurationSec}" else "Voice Note (0:${message.voiceDurationSec})",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = GoldLight,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }
                    MessageType.IMAGE -> {
                        Column {
                            Image(
                                painter = painterResource(id = R.drawable.img_hero_luxury),
                                contentDescription = "Shared photo",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = message.text,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextLightGrey)
                            )
                        }
                    }
                    else -> Unit
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Timestamp & read ticks
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = message.timestamp,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    )
                    if (isMe) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.DoneAll,
                            contentDescription = "Read",
                            tint = if (message.isRead) GoldPrimary else TextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
