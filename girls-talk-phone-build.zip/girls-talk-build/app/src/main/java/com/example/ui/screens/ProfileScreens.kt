package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.SampleData
import com.example.model.PrivacySettings
import com.example.model.UserRole
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.AppLanguage
import com.example.util.Strings
import com.example.viewmodel.GirlsTalkViewModel
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.UiState

@Composable
fun ProfileScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    val user = state.currentUser

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Profile Header Card
        GoldCard(
            modifier = Modifier.fillMaxWidth(),
            borderWidth = 1.dp,
            borderColor = GoldBorder,
            backgroundColor = CardSurface
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(92.dp)
                            .clip(CircleShape)
                            .border(2.dp, GoldPrimary, CircleShape)
                            .background(CharcoalBg),
                        contentAlignment = Alignment.Center
                    ) {
                        val res = user.avatarRes ?: R.drawable.ic_launcher_girls_talk
                        Image(
                            painter = painterResource(id = res),
                            contentDescription = user.name,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(GoldPrimary)
                            .align(Alignment.BottomEnd),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Verified",
                            tint = DeepBlack,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = user.name,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = PlayfairFontFamily,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                )

                Text(
                    text = "@${user.username} • ${user.city}, ${user.country}",
                    style = MaterialTheme.typography.bodySmall.copy(color = GoldLight)
                )

                Spacer(modifier = Modifier.height(8.dp))

                VerifiedBadge(status = user.verificationStatus)

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = user.bio,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextLightGrey,
                        lineHeight = 20.sp
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Stats row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CharcoalBg, RoundedCornerShape(12.dp))
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "100%", style = MaterialTheme.typography.titleMedium.copy(color = GoldPrimary, fontWeight = FontWeight.Bold))
                        Text(text = "Trust Rating", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 10.sp))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "18+", style = MaterialTheme.typography.titleMedium.copy(color = GoldPrimary, fontWeight = FontWeight.Bold))
                        Text(text = "Verified Adult", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 10.sp))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "4", style = MaterialTheme.typography.titleMedium.copy(color = GoldPrimary, fontWeight = FontWeight.Bold))
                        Text(text = "Clubs Joined", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 10.sp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Quick Testing Toolbar
        Text(
            text = "SANCTUARY SHORTCUTS & DEMO TOOLS",
            style = MaterialTheme.typography.labelSmall.copy(
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GoldOutlinedButton(
                text = "Simulate Audio Call",
                onClick = { viewModel.triggerIncomingCallDemo(isVideo = false) },
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Call
            )
            GoldOutlinedButton(
                text = "Simulate Video Call",
                onClick = { viewModel.triggerIncomingCallDemo(isVideo = true) },
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Videocam
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Menu Options List
        GoldCard(
            modifier = Modifier.fillMaxWidth(),
            borderWidth = 1.dp,
            borderColor = GoldBorder,
            backgroundColor = CardSurface
        ) {
            ProfileMenuRow(
                icon = Icons.Default.Security,
                title = Strings.get("settings", lang),
                subtitle = "Manage visibility of age, city, and direct messages",
                onClick = { viewModel.navigateTo(ScreenDestination.PRIVACY_SETTINGS) }
            )

            HorizontalDivider(color = GoldBorder.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 4.dp))

            ProfileMenuRow(
                icon = Icons.Default.Shield,
                title = Strings.get("help_support", lang),
                subtitle = "Emergency hotlines, safety advice & zero harassment guide",
                onClick = { viewModel.navigateTo(ScreenDestination.SAFETY_CENTER) }
            )

            HorizontalDivider(color = GoldBorder.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 4.dp))

            ProfileMenuRow(
                icon = Icons.Default.Block,
                title = Strings.get("blocked_accounts", lang),
                subtitle = "${state.blockedUsers.size} accounts blocked",
                onClick = { viewModel.navigateTo(ScreenDestination.BLOCKED_USERS) }
            )

            HorizontalDivider(color = GoldBorder.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 4.dp))

            ProfileMenuRow(
                icon = Icons.Default.AdminPanelSettings,
                title = Strings.get("admin_dashboard", lang),
                subtitle = "Authorized administration, verification queue & audit",
                onClick = { viewModel.navigateTo(ScreenDestination.ADMIN_DASHBOARD) }
            )

            HorizontalDivider(color = GoldBorder.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 4.dp))

            ProfileMenuRow(
                icon = Icons.Default.Translate,
                title = Strings.get("language_setting", lang),
                subtitle = if (lang == AppLanguage.ENGLISH) "English (বর্তমান ভাষা)" else "বাংলা (Current language)",
                onClick = { viewModel.toggleLanguage() }
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Role Switcher & Logout
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val isAdmin = user.role == UserRole.ADMIN
            GoldOutlinedButton(
                text = if (isAdmin) "Switch to Member Mode" else "Switch to Admin Mode",
                onClick = { viewModel.switchAccountRole(toAdmin = !isAdmin) },
                modifier = Modifier.weight(1f)
            )

            GoldButton(
                text = Strings.get("logout", lang),
                onClick = { viewModel.logout() },
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Logout
            )
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
private fun ProfileMenuRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(CharcoalBg)
                .border(1.dp, GoldBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge.copy(color = TextWhite, fontWeight = FontWeight.SemiBold))
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp))
        }
        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = GoldLight)
    }
}

@Composable
fun PrivacySettingsScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    val privacy = state.currentUser.privacySettings

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        IconButton(
            onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) },
            modifier = Modifier.size(40.dp)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = Strings.get("settings", lang),
            style = MaterialTheme.typography.displayMedium.copy(
                fontFamily = PlayfairFontFamily,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
        )
        Text(
            text = "Granular privacy toggles for your sanctuary profile.",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextLightGrey)
        )

        Spacer(modifier = Modifier.height(24.dp))

        GoldCard(
            modifier = Modifier.fillMaxWidth(),
            borderWidth = 1.dp,
            borderColor = GoldBorder,
            backgroundColor = CardSurface
        ) {
            PrivacyToggleRow(
                title = Strings.get("show_age", lang),
                description = "Allow other verified women to see your age (29)",
                checked = privacy.showAge,
                onCheckedChange = { viewModel.updatePrivacySettings(privacy.copy(showAge = it)) }
            )

            HorizontalDivider(color = GoldBorder.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

            PrivacyToggleRow(
                title = Strings.get("show_location", lang),
                description = "Display your city (${state.currentUser.city}) and country",
                checked = privacy.showLocation,
                onCheckedChange = { viewModel.updatePrivacySettings(privacy.copy(showLocation = it)) }
            )

            HorizontalDivider(color = GoldBorder.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

            PrivacyToggleRow(
                title = Strings.get("show_online", lang),
                description = "Show active status indicator when inside the app",
                checked = privacy.showOnlineStatus,
                onCheckedChange = { viewModel.updatePrivacySettings(privacy.copy(showOnlineStatus = it)) }
            )

            HorizontalDivider(color = GoldBorder.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

            PrivacyToggleRow(
                title = Strings.get("allow_dms", lang),
                description = "Receive direct encrypted messages from any verified sister",
                checked = privacy.allowDirectMessages,
                onCheckedChange = { viewModel.updatePrivacySettings(privacy.copy(allowDirectMessages = it)) }
            )

            HorizontalDivider(color = GoldBorder.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

            PrivacyToggleRow(
                title = "Allow Audio & Video Calls",
                description = "Allow incoming encrypted calls from connected sisters",
                checked = privacy.allowCalls,
                onCheckedChange = { viewModel.updatePrivacySettings(privacy.copy(allowCalls = it)) }
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        GoldButton(
            text = "Save Preferences",
            onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun PrivacyToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge.copy(color = TextWhite, fontWeight = FontWeight.SemiBold))
            Text(text = description, style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = DeepBlack,
                checkedTrackColor = GoldPrimary,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = CharcoalBg
            )
        )
    }
}

@Composable
fun SafetyCenterScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        IconButton(
            onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) },
            modifier = Modifier.size(40.dp)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.img_safety_shield),
                contentDescription = null,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = Strings.get("help_support", lang),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = PlayfairFontFamily,
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold
                )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "GIRLS TALK Sanctuary operates with zero tolerance for harassment, stalking, or unauthorized male access. All members are verified adult women (18+). If you ever feel uncomfortable, our moderation team responds 24/7.",
            style = MaterialTheme.typography.bodyMedium.copy(color = TextLightGrey, lineHeight = 22.sp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "EMERGENCY WOMEN HELPLINES",
            style = MaterialTheme.typography.labelSmall.copy(
                color = DangerRed,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        SampleData.safetyHelplines.forEach { (name, number) ->
            GoldCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                borderWidth = 1.dp,
                borderColor = GoldBorder,
                backgroundColor = CardSurface
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = name, style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                        Text(text = "Toll-Free 24/7 Emergency", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp))
                    }
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x334CAF50))
                            .border(1.dp, StatusOnline, RoundedCornerShape(12.dp))
                    ) {
                        Text(
                            text = number,
                            style = MaterialTheme.typography.labelLarge.copy(color = StatusOnline, fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BlockedUsersScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        IconButton(
            onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) },
            modifier = Modifier.size(40.dp)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = Strings.get("blocked_accounts", lang),
            style = MaterialTheme.typography.displayMedium.copy(
                fontFamily = PlayfairFontFamily,
                color = GoldPrimary,
                fontWeight = FontWeight.Bold
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (state.blockedUsers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "No blocked members", style = MaterialTheme.typography.bodyLarge.copy(color = TextWhite))
                    Text(text = "Your private sanctuary experience is peaceful.", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted))
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(state.blockedUsers) { user ->
                    GoldCard(
                        modifier = Modifier.fillMaxWidth(),
                        borderWidth = 1.dp,
                        borderColor = GoldBorder,
                        backgroundColor = CardSurface
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AvatarWithStatus(user = user, size = 44.dp, showOnlineStatus = false)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(text = user.name, style = MaterialTheme.typography.bodyLarge.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                                    Text(text = "@${user.username}", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted))
                                }
                            }
                            GoldOutlinedButton(
                                text = Strings.get("unblock", lang),
                                onClick = { viewModel.unblockUser(user) },
                                modifier = Modifier.height(34.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportMemberScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    val target = state.reportingTargetUser ?: return
    var selectedReason by remember { mutableStateOf("Harassment or Inappropriate Behavior") }
    var notes by remember { mutableStateOf("") }
    val reasons = listOf(
        "Harassment or Inappropriate Behavior",
        "Suspected Impersonation / Fake Gender Profile",
        "Spam, Commercial Promotion or Unsolicited Links",
        "Violation of 18+ Private Sanctuary Code"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        IconButton(
            onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) },
            modifier = Modifier.size(40.dp)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Flag, contentDescription = null, tint = DangerRed, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "Report Member to Safety Team",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = PlayfairFontFamily,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold
                )
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Reporting: ${target.name} (@${target.username})",
            style = MaterialTheme.typography.bodyMedium.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Select Violation Reason:",
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(8.dp))

        reasons.forEach { reason ->
            val isSelected = selectedReason == reason
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, if (isSelected) GoldPrimary else GoldBorder, RoundedCornerShape(10.dp))
                    .clickable { selectedReason = reason },
                color = if (isSelected) Color(0x33D4AF37) else CardSurface
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { selectedReason = reason },
                        colors = RadioButtonDefaults.colors(selectedColor = GoldPrimary)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = reason, style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Additional Details / Incident Context:",
            style = MaterialTheme.typography.labelLarge.copy(color = GoldLight, fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it },
            placeholder = { Text("Describe what happened...", color = TextMuted) },
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(28.dp))

        GoldButton(
            text = "Submit Confidential Report",
            onClick = { viewModel.submitReport(selectedReason, notes) },
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Default.Send
        )
    }
}
