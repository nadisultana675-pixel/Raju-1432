package com.example.util

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    BENGALI("bn", "Bengali", "বাংলা")
}

object Strings {
    fun get(key: String, lang: AppLanguage): String {
        val map = if (lang == AppLanguage.BENGALI) bengaliStrings else englishStrings
        return map[key] ?: englishStrings[key] ?: key
    }

    private val englishStrings = mapOf(
        "app_name" to "GIRLS TALK",
        "tagline" to "A Private Community for Verified Adult Women",
        "tagline_sub" to "Safe • Confidential • Verified 18+",
        "nav_home" to "Home",
        "nav_discover" to "Discover",
        "nav_chats" to "Chats",
        "nav_communities" to "Clubs",
        "nav_profile" to "Profile",
        
        // Auth
        "welcome_title" to "Exclusively for Women",
        "welcome_desc" to "Enter a sanctuary designed for authentic connections, mutual empowerment, and genuine security.",
        "get_started" to "Get Started",
        "login" to "Sign In",
        "register" to "Create Account",
        "phone_number" to "Mobile Number",
        "phone_placeholder" to "+1 (555) 000-0000 / +880 1...",
        "email_optional" to "Email Address (Optional)",
        "password" to "Password",
        "forgot_password" to "Forgot Password?",
        "enter_otp" to "Verify Mobile Number",
        "otp_subtitle" to "Enter the 6-digit verification code sent to your phone",
        "resend_otp" to "Resend Code",
        "verify_continue" to "Verify & Continue",
        "demo_login_member" to "Demo Member Login",
        "demo_login_admin" to "Admin Portal Login",
        
        // Age & Identity Verification
        "verification_title" to "18+ Adult Woman Verification",
        "verification_subtitle" to "Our zero-tolerance safety protocol ensures every member is a verified adult woman (18+).",
        "dob_label" to "Date of Birth (Must be 18+)",
        "id_type_label" to "Government Identity Document Type",
        "id_doc_number" to "Document Reference / ID Number",
        "id_passport" to "National Passport",
        "id_nid" to "National ID Card / Smart Card",
        "id_drivers" to "Driver's License",
        "verification_consent" to "I solemnly confirm I am an adult woman aged 18 or above. I consent to secure identity verification for community safety. Identity documents are processed with end-to-end encryption.",
        "submit_verification" to "Submit for Verification",
        "verification_status_verified" to "Identity Verified (18+ Adult Woman)",
        "verification_status_pending" to "Verification Under Review",
        "verification_status_rejected" to "Verification Requires Re-submission",
        
        // Profile setup
        "setup_profile" to "Setup Profile",
        "display_name" to "Display Name",
        "city" to "City",
        "country" to "Country",
        "bio" to "Biography",
        "interests" to "Interests & Passions",
        "save_profile" to "Save & Enter Sanctuary",
        
        // Home
        "featured_sanctuary" to "The Sanctuary",
        "community_feed" to "Community Voices",
        "create_post" to "Share with sisters...",
        "post_btn" to "Publish",
        "safety_sos" to "Safety & Helplines",
        "like" to "Like",
        "comment" to "Comment",
        "comments" to "Comments",
        "share" to "Share",
        
        // Discover
        "discover_members" to "Verified Members",
        "search_members_hint" to "Search by name, city, interest...",
        "filter_all" to "All",
        "filter_online" to "Online Now",
        "filter_bangladesh" to "Bangladesh",
        "filter_usa" to "United States",
        "filter_uk" to "United Kingdom",
        "filter_canada" to "Canada",
        "connect" to "Connect",
        "connected" to "Connected",
        "start_chat" to "Message",
        
        // Chat
        "private_chats" to "Private Messages",
        "type_message" to "Type a message...",
        "voice_message" to "Voice Note",
        "recording" to "Recording voice message...",
        "send" to "Send",
        "call_audio" to "Audio Call",
        "call_video" to "Video Call",
        "delete_message" to "Delete Message",
        "block_user" to "Block Member",
        "report_user" to "Report Member",
        "safety_encrypted" to "End-to-End Encrypted Private Chat",
        
        // Calling
        "incoming_audio_call" to "Incoming Audio Call",
        "incoming_video_call" to "Incoming Video Call",
        "active_call" to "Encrypted Call in Progress",
        "mute" to "Mute",
        "unmute" to "Unmute",
        "speaker" to "Speaker",
        "switch_cam" to "Flip Camera",
        "end_call" to "End Call",
        "accept" to "Accept",
        "decline" to "Decline",
        
        // Settings & Privacy
        "settings" to "Settings & Privacy",
        "language_setting" to "Language / ভাষা",
        "show_age" to "Display Age on Profile",
        "show_location" to "Display City & Country",
        "show_online" to "Show Online Status",
        "allow_dms" to "Allow Direct Messages from Non-Friends",
        "blocked_accounts" to "Blocked Members",
        "unblock" to "Unblock",
        "help_support" to "Safety Center & Helplines",
        "admin_dashboard" to "Admin Dashboard",
        "logout" to "Sign Out",
        
        // Admin
        "admin_portal" to "Administration Dashboard",
        "stat_total_users" to "Total Users",
        "stat_verified" to "Verified Women",
        "stat_pending_verif" to "Pending Review",
        "stat_reports" to "Pending Reports",
        "pending_verifications" to "Identity Verification Queue",
        "approve" to "Approve (Grant Verified Badge)",
        "reject" to "Reject",
        "reported_cases" to "Reported Content & Harassment",
        "dismiss_report" to "Dismiss",
        "suspend_user" to "Suspend Account",
        "audit_logs" to "Security Audit Logs"
    )

    private val bengaliStrings = mapOf(
        "app_name" to "গার্লস টক",
        "tagline" to "ভেরিফায়েড প্রাপ্তবয়স্ক নারীদের জন্য একটি একান্ত কমিউনিটি",
        "tagline_sub" to "নিরাপদ • গোপনীয় • ভেরিফায়েড ১৮+",
        "nav_home" to "হোম",
        "nav_discover" to "আবিষ্কার",
        "nav_chats" to "চ্যাট",
        "nav_communities" to "ক্লাব",
        "nav_profile" to "প্রোফাইল",
        
        // Auth
        "welcome_title" to "শুধুমাত্র নারীদের জন্য",
        "welcome_desc" to "একটি নির্ভরযোগ্য নিরাপদ পরিবেশ যেখানে আপনি আত্মবিশ্বাসের সাথে যোগাযোগ, অভিজ্ঞতা বিনিময় ও পরস্পরকে অনুপ্রাণিত করতে পারবেন।",
        "get_started" to "শুরু করুন",
        "login" to "সাইন ইন",
        "register" to "নতুন অ্যাকাউন্ট",
        "phone_number" to "মোবাইল নম্বর",
        "phone_placeholder" to "+৮৮০ ১...",
        "email_optional" to "ইমেইল ঠিকানা (ঐচ্ছিক)",
        "password" to "পাসওয়ার্ড",
        "forgot_password" to "পাসওয়ার্ড ভুলে গেছেন?",
        "enter_otp" to "মোবাইল নম্বর যাচাই",
        "otp_subtitle" to "আপনার মোবাইলে পাঠানো ৬ সংখ্যার ওটিপি কোডটি লিখুন",
        "resend_otp" to "কোড পুনরায় পাঠান",
        "verify_continue" to "যাচাই করে এগিয়ে যান",
        "demo_login_member" to "সদস্য হিসেবে ডেমো লগইন",
        "demo_login_admin" to "অ্যাডমিন হিসেবে লগইন",
        
        // Age & Identity Verification
        "verification_title" to "১৮+ প্রাপ্তবয়স্ক নারী যাচাইকরণ",
        "verification_subtitle" to "আমাদের কঠোর নিরাপত্তা ব্যবস্থা নিশ্চিত করে যে প্রতি সদস্য একজন ভেরিফায়েড ১৮+ প্রাপ্তবয়স্ক নারী।",
        "dob_label" to "জন্ম তারিখ (অবশ্যই ১৮+ হতে হবে)",
        "id_type_label" to "সরকারি পরিচয়পত্রের ধরন",
        "id_doc_number" to "পরিচয়পত্র নম্বর / রেফারেন্স",
        "id_passport" to "আন্তর্জাতিক পাসপোর্ট",
        "id_nid" to "জাতীয় পরিচয়পত্র (NID) / স্মার্ট কার্ড",
        "id_drivers" to "ড্রাইভিং লাইসেন্স",
        "verification_consent" to "আমি নিশ্চয়তা দিচ্ছি যে আমি একজন প্রাপ্তবয়স্ক নারী (বয়স ১৮ বা তদূর্ধ্ব)। কমিউনিটির নিরাপত্তার স্বার্থে সুরক্ষিত পরিচয় যাচাইয়ে সম্মতি জানাচ্ছি। পরিচয় তথ্য সম্পূর্ণ এনক্রিপ্ট রাখা হয়।",
        "submit_verification" to "যাচাইয়ের জন্য জমা দিন",
        "verification_status_verified" to "পরিচয় যাচাইকৃত (১৮+ প্রাপ্তবয়স্ক নারী)",
        "verification_status_pending" to "যাচাই প্রক্রিয়াধীন রয়েছে",
        "verification_status_rejected" to "পুনরায় যাচাইয়ের আবেদন করুন",
        
        // Profile setup
        "setup_profile" to "প্রোফাইল তৈরি",
        "display_name" to "আপনার নাম",
        "city" to "শহর",
        "country" to "দেশ",
        "bio" to "সংক্ষিপ্ত পরিচিতি",
        "interests" to "আগ্রহ ও শখ",
        "save_profile" to "সংরক্ষণ করুন",
        
        // Home
        "featured_sanctuary" to "সেন্টুয়ারি",
        "community_feed" to "সদস্যদের আলোচনা",
        "create_post" to "বোনেদের সাথে কিছু শেয়ার করুন...",
        "post_btn" to "পোস্ট করুন",
        "safety_sos" to "নিরাপত্তা ও হেল্পলাইন",
        "like" to "পছন্দ",
        "comment" to "মন্তব্য",
        "comments" to "মন্তব্যসমূহ",
        "share" to "শেয়ার",
        
        // Discover
        "discover_members" to "যাচাইকৃত নারী সদস্যবৃন্দ",
        "search_members_hint" to "নাম, শহর বা বিষয় দিয়ে খুঁজুন...",
        "filter_all" to "সকল",
        "filter_online" to "অনলাইনে আছেন",
        "filter_bangladesh" to "বাংলাদেশ",
        "filter_usa" to "যুক্তরাষ্ট্র",
        "filter_uk" to "যুক্তরাজ্য",
        "filter_canada" to "কানাডা",
        "connect" to "যুক্ত হন",
        "connected" to "যুক্ত আছেন",
        "start_chat" to "মেসেজ পাঠান",
        
        // Chat
        "private_chats" to "ব্যক্তিগত বার্তা",
        "type_message" to "বার্তা লিখুন...",
        "voice_message" to "ভয়েস মেসেজ",
        "recording" to "ভয়েস রেকর্ড হচ্ছে...",
        "send" to "পাঠান",
        "call_audio" to "অডিও কল",
        "call_video" to "ভিডিও কল",
        "delete_message" to "বার্তা মুছুন",
        "block_user" to "ব্লক করুন",
        "report_user" to "রিপোর্ট করুন",
        "safety_encrypted" to "এন্ড-টু-এন্ড এনক্রিপ্ট করা চ্যাট",
        
        // Calling
        "incoming_audio_call" to "ইনকামিং অডিও কল",
        "incoming_video_call" to "ইনকামিং ভিডিও কল",
        "active_call" to "এনক্রিপ্ট করা কল চলছে",
        "mute" to "মিউট",
        "unmute" to "আনমিউট",
        "speaker" to "স্পিকার",
        "switch_cam" to "ক্যামেরা পরিবর্তন",
        "end_call" to "কল শেষ করুন",
        "accept" to "গ্রহণ করুন",
        "decline" to "প্রত্যাখ্যান",
        
        // Settings & Privacy
        "settings" to "সেটিংস ও গোপনীয়তা",
        "language_setting" to "ভাষা পরিবর্তন",
        "show_age" to "প্রোফাইলে বয়স দেখান",
        "show_location" to "শহর ও দেশ প্রদর্শন করুন",
        "show_online" to "অনলাইন স্ট্যাটাস দেখান",
        "allow_dms" to "সরাসরি বার্তা পাঠানোর অনুমতি",
        "blocked_accounts" to "ব্লক করা অ্যাকাউন্টসমূহ",
        "unblock" to "আনব্লক",
        "help_support" to "নিরাপত্তা কেন্দ্র ও হেল্পলাইন",
        "admin_dashboard" to "অ্যাডমিন প্যানেল",
        "logout" to "লগআউট",
        
        // Admin
        "admin_portal" to "অ্যাডমিনিস্ট্রেশন ড্যাশবোর্ড",
        "stat_total_users" to "মোট সদস্য",
        "stat_verified" to "যাচাইকৃত নারী",
        "stat_pending_verif" to "বিচারাধীন যাচাই",
        "stat_reports" to "রিপোর্টের সংখ্যা",
        "pending_verifications" to "পরিচয় যাচাইকরণ তালিকা",
        "approve" to "অনুমোদন করুন (ভেরিফায়েড ব্যাজ)",
        "reject" to "বাতিল করুন",
        "reported_cases" to "রিপোর্ট ও হয়রানি প্রতিরোধ",
        "dismiss_report" to "রিপোর্ট খারিজ",
        "suspend_user" to "অ্যাকাউন্ট স্থগিত",
        "audit_logs" to "নিরাপত্তা নিরীক্ষা লগ"
    )
}
