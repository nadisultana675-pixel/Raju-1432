package com.example.data

import com.example.R
import com.example.model.*

object SampleData {

    // Current User (Demo verified member)
    val currentMember = User(
        id = "usr_001",
        name = "Tasnim Chowdhury",
        username = "tasnim_c",
        age = 29,
        dateOfBirth = "1997-04-12",
        city = "Dhaka",
        country = "Bangladesh",
        bio = "Architect & Design Consultant. Advocate for women leadership in STEM. Passionate about classical music & interior curation.",
        avatarRes = R.drawable.img_avatar_sample,
        interests = listOf("Architecture", "Entrepreneurship", "Art & Literature", "Mindfulness"),
        isVerified = true,
        verificationStatus = VerificationStatus.VERIFIED,
        verificationDocRef = "NID-***-8492-ENC",
        isOnline = true,
        lastSeen = "Online",
        privacySettings = PrivacySettings(
            showAge = true,
            showLocation = true,
            showOnlineStatus = true,
            allowDirectMessages = true,
            allowCalls = true
        ),
        role = UserRole.MEMBER
    )

    // Admin Account (Authorized administrator for moderation)
    val adminUser = User(
        id = "admin_001",
        name = "Amina Rahman (Chief Moderator)",
        username = "moderator_amina",
        age = 38,
        dateOfBirth = "1988-09-20",
        city = "London",
        country = "United Kingdom",
        bio = "Community Safety Director & Senior Compliance Lead for GIRLS TALK Sanctuary.",
        avatarRes = R.drawable.ic_launcher_girls_talk,
        interests = listOf("Cyber Safety", "Law", "Community Governance"),
        isVerified = true,
        verificationStatus = VerificationStatus.VERIFIED,
        verificationDocRef = "PASSPORT-***-1109-UK",
        isOnline = true,
        lastSeen = "Active",
        role = UserRole.ADMIN
    )

    // Verified Community Members (Test Accounts clearly marked)
    val sampleMembers = listOf(
        User(
            id = "usr_002",
            name = "Dr. Farhana Ahmed",
            username = "farhana_doc",
            age = 34,
            dateOfBirth = "1992-06-18",
            city = "Chittagong",
            country = "Bangladesh",
            bio = "Pediatric Cardiologist & Mother of two. Loving books, travel photography, and women's wellness discussions. [Test Account]",
            avatarRes = R.drawable.img_avatar_sample,
            interests = listOf("Medicine", "Motherhood", "Wellness", "Photography"),
            isVerified = true,
            verificationStatus = VerificationStatus.VERIFIED,
            verificationDocRef = "NID-***-3301-BD",
            isOnline = true,
            lastSeen = "Online"
        ),
        User(
            id = "usr_003",
            name = "Sophia Laurent",
            username = "sophia_ny",
            age = 31,
            dateOfBirth = "1995-02-14",
            city = "New York",
            country = "United States",
            bio = "Fintech product manager & angel investor. Dedicated to supporting female founders globally. [Test Account]",
            avatarRes = R.drawable.img_hero_luxury,
            interests = listOf("Fintech", "Investing", "Travel", "Haute Couture"),
            isVerified = true,
            verificationStatus = VerificationStatus.VERIFIED,
            verificationDocRef = "PASS-***-9021-US",
            isOnline = true,
            lastSeen = "Online"
        ),
        User(
            id = "usr_004",
            name = "Nusrat Jahan",
            username = "nusrat_creative",
            age = 26,
            dateOfBirth = "2000-11-05",
            city = "Sylhet",
            country = "Bangladesh",
            bio = "Visual artist & boutique owner. Preserving heritage textiles & sustainable fashion. [Test Account]",
            avatarRes = R.drawable.ic_launcher_girls_talk,
            interests = listOf("Fashion", "Art & Literature", "Business", "Crafts"),
            isVerified = true,
            verificationStatus = VerificationStatus.VERIFIED,
            verificationDocRef = "SMART-***-7721-BD",
            isOnline = false,
            lastSeen = "25m ago"
        ),
        User(
            id = "usr_005",
            name = "Elena Rostova",
            username = "elena_toronto",
            age = 28,
            dateOfBirth = "1998-08-30",
            city = "Toronto",
            country = "Canada",
            bio = "Cybersecurity analyst & pianist. Advocate for online privacy and safe digital spaces for women. [Test Account]",
            avatarRes = R.drawable.img_safety_shield,
            interests = listOf("Cyber Safety", "Classical Music", "Fitness", "Tech"),
            isVerified = true,
            verificationStatus = VerificationStatus.VERIFIED,
            verificationDocRef = "DL-***-4091-CA",
            isOnline = true,
            lastSeen = "Online"
        ),
        User(
            id = "usr_006",
            name = "Meherun Nisa",
            username = "meherun_law",
            age = 42,
            dateOfBirth = "1984-01-19",
            city = "Dhaka",
            country = "Bangladesh",
            bio = "Supreme Court Advocate specializing in women's rights and family legal advisory. [Test Account]",
            avatarRes = R.drawable.img_avatar_sample,
            interests = listOf("Law", "Human Rights", "Reading", "Mentorship"),
            isVerified = true,
            verificationStatus = VerificationStatus.VERIFIED,
            verificationDocRef = "NID-***-5582-BD",
            isOnline = false,
            lastSeen = "1h ago"
        )
    )

    // Sample Conversations
    val initialConversations = listOf(
        Conversation(
            id = "conv_001",
            participant = sampleMembers[0], // Dr. Farhana
            lastMessage = ChatMessage(
                id = "msg_001",
                conversationId = "conv_001",
                senderId = "usr_002",
                senderName = "Dr. Farhana Ahmed",
                text = "Thank you so much for the architecture blueprints review! Looking forward to our call tomorrow evening.",
                type = MessageType.TEXT,
                timestamp = "10:42 AM",
                isRead = true
            ),
            unreadCount = 0
        ),
        Conversation(
            id = "conv_002",
            participant = sampleMembers[1], // Sophia Laurent
            lastMessage = ChatMessage(
                id = "msg_002",
                conversationId = "conv_002",
                senderId = "usr_003",
                senderName = "Sophia Laurent",
                text = "Voice message (0:48)",
                type = MessageType.VOICE,
                voiceDurationSec = 48,
                timestamp = "Yesterday",
                isRead = false
            ),
            unreadCount = 1
        ),
        Conversation(
            id = "conv_003",
            participant = sampleMembers[2], // Nusrat Jahan
            lastMessage = ChatMessage(
                id = "msg_003",
                conversationId = "conv_003",
                senderId = "usr_001",
                senderName = "Tasnim Chowdhury",
                text = "I loved your new hand-woven silk collection! Will visit your boutique this Saturday.",
                type = MessageType.TEXT,
                timestamp = "Nov 6",
                isRead = true
            ),
            unreadCount = 0
        ),
        Conversation(
            id = "conv_004",
            participant = sampleMembers[3], // Elena Rostova
            lastMessage = ChatMessage(
                id = "msg_004",
                conversationId = "conv_004",
                senderId = "usr_005",
                senderName = "Elena Rostova",
                text = "Shared an article on end-to-end encryption in private networks.",
                type = MessageType.TEXT,
                timestamp = "Nov 4",
                isRead = true
            ),
            unreadCount = 0
        )
    )

    // Detailed Messages for conv_001
    val initialChatMessages = listOf(
        ChatMessage(
            id = "m1",
            conversationId = "conv_001",
            senderId = "usr_002",
            senderName = "Dr. Farhana Ahmed",
            text = "Assalamu Alaikum Tasnim! Hope you are having a wonderful week.",
            timestamp = "10:15 AM",
            isRead = true
        ),
        ChatMessage(
            id = "m2",
            conversationId = "conv_001",
            senderId = "usr_001",
            senderName = "Tasnim Chowdhury",
            text = "Wa Alaikum Assalam Farhana Apa! Everything is going great. How are the kids?",
            timestamp = "10:20 AM",
            isRead = true
        ),
        ChatMessage(
            id = "m3",
            conversationId = "conv_001",
            senderId = "usr_002",
            senderName = "Dr. Farhana Ahmed",
            text = "They are energetic as always! I sent the clinic floor plan to your email.",
            timestamp = "10:30 AM",
            isRead = true
        ),
        ChatMessage(
            id = "m4",
            conversationId = "conv_001",
            senderId = "usr_002",
            senderName = "Dr. Farhana Ahmed",
            text = "Voice message (0:35)",
            type = MessageType.VOICE,
            voiceDurationSec = 35,
            timestamp = "10:36 AM",
            isRead = true
        ),
        ChatMessage(
            id = "m5",
            conversationId = "conv_001",
            senderId = "usr_001",
            senderName = "Tasnim Chowdhury",
            text = "Listened to the note. I will optimize the natural lighting in the pediatric waiting lounge so it feels soothing for young patients.",
            timestamp = "10:40 AM",
            isRead = true
        ),
        ChatMessage(
            id = "m6",
            conversationId = "conv_001",
            senderId = "usr_002",
            senderName = "Dr. Farhana Ahmed",
            text = "Thank you so much for the architecture blueprints review! Looking forward to our call tomorrow evening.",
            timestamp = "10:42 AM",
            isRead = true
        )
    )

    // Community Feed Posts
    val initialPosts = listOf(
        CommunityPost(
            id = "post_001",
            author = sampleMembers[1], // Sophia
            category = "Entrepreneurship & Leadership",
            content = "Excited to announce our new angel syndicate dedicated to supporting female-founded tech startups in South Asia and MENA! If any sister here is building something bold, my DMs are open for pitch deck mentorship.",
            likesCount = 42,
            commentsCount = 8,
            isLiked = true,
            timestamp = "2 hours ago",
            comments = listOf(
                PostComment("c1", sampleMembers[0], "Incredible initiative Sophia! Women founders bring such empathy and resilience to leadership.", "1h ago"),
                PostComment("c2", currentMember, "So proud of this vision! Would love to share this with our creative circle.", "45m ago")
            )
        ),
        CommunityPost(
            id = "post_002",
            author = sampleMembers[0], // Dr. Farhana
            category = "Wellness & Mental Health",
            content = "Friendly reminder to all our hardworking sisters: Self-care is not a luxury, it is a clinical necessity. Take 15 minutes of quiet mindfulness today without screens, drink warm herbal tea, and breathe deeply.",
            likesCount = 89,
            commentsCount = 14,
            isLiked = false,
            timestamp = "5 hours ago",
            comments = listOf(
                PostComment("c3", sampleMembers[2], "Needed this reminder today amidst textile weaving deadlines. Thank you doctor!", "3h ago")
            )
        ),
        CommunityPost(
            id = "post_003",
            author = sampleMembers[2], // Nusrat
            category = "Creative Arts & Heritage",
            content = "Reviving traditional Jamdani and Muslin motifs into modern luxury evening wear. Each thread represents generations of heritage. What are your favorite heirloom pieces passed down by your grandmothers?",
            likesCount = 63,
            commentsCount = 19,
            isLiked = true,
            timestamp = "Yesterday",
            comments = emptyList()
        )
    )

    // Interest-Based Communities / Clubs
    val initialGroups = listOf(
        CommunityGroup(
            id = "grp_001",
            name = "Female Founders & Investors",
            nameBn = "নারী উদ্যোক্তা ও বিনিয়োগকারী ফোরাম",
            description = "A private boardroom for women founders, business executives, and angel investors to network and co-invest.",
            descriptionBn = "নারী উদ্যোক্তা ও পরিচালকদের ব্যবসায়িক নেটওয়ার্ক এবং পারস্পরিক বিনিয়োগ ফোরাম।",
            memberCount = 1420,
            category = "Business",
            isJoined = true,
            recentDiscussion = "Seed round fundraising strategies in 2026"
        ),
        CommunityGroup(
            id = "grp_002",
            name = "Holistic Wellness & Mindfulness",
            nameBn = "স্বাস্থ্য, সুস্বাস্থ্য ও মানসিক প্রশান্তি",
            description = "Nutrition, mental health, yoga, and medical advice curated by certified female physicians.",
            descriptionBn = "মহিলা চিকিৎসকদের তত্ত্বাবধানে স্বাস্থ্য, মানসিক প্রশান্তি ও জীবনযাত্রার পরম পরামর্শ।",
            memberCount = 2890,
            category = "Health",
            isJoined = true,
            recentDiscussion = "Balancing demanding careers and hormone wellness"
        ),
        CommunityGroup(
            id = "grp_003",
            name = "Literature, Poetry & Arts",
            nameBn = "সাহিত্য, কবিতা ও শিল্পকলা",
            description = "Monthly book club, creative writing critique, and appreciation of Bengali and global literature.",
            descriptionBn = "বই পাঠের আনন্দ, সাহিত্য আলোচনা ও সৃজনশীল লেখার আসর।",
            memberCount = 980,
            category = "Culture",
            isJoined = false,
            recentDiscussion = "Discussing modern Bengali feminist poetry"
        ),
        CommunityGroup(
            id = "grp_004",
            name = "Women in Tech & STEM",
            nameBn = "প্রযুক্তি ও বিজ্ঞানে নারী",
            description = "Software engineers, data scientists, and researchers discussing AI, cloud architectures, and career growth.",
            descriptionBn = "সফটওয়্যার প্রকৌশলী এবং গবেষক বোনদের পেশাগত উন্নতি ও প্রযুক্তি আড্ডা।",
            memberCount = 1650,
            category = "Technology",
            isJoined = true,
            recentDiscussion = "Ethical AI safety protocols"
        ),
        CommunityGroup(
            id = "grp_005",
            name = "Luxury Fashion & Lifestyle",
            nameBn = "লাক্সারি ফ্যাশন ও জীবনধারা",
            description = "Haute couture, sustainable luxury styling, interior architecture, and vintage jewellery.",
            descriptionBn = "অভিজাত ফ্যাশন, পোশাক ডিজাইন, ইনটেরিয়র এবং নান্দনিক জীবনধারা।",
            memberCount = 2100,
            category = "Lifestyle",
            isJoined = false,
            recentDiscussion = "Curating an intentional minimalist capsule wardrobe"
        )
    )

    // Notifications
    val initialNotifications = listOf(
        NotificationItem(
            id = "notif_001",
            title = "Identity Verified Successfully",
            message = "Congratulations Tasnim! Your 18+ adult woman verification has been certified. Golden verification badge activated.",
            type = NotificationType.VERIFICATION,
            timestamp = "10m ago",
            isRead = false
        ),
        NotificationItem(
            id = "notif_002",
            title = "Incoming Video Call Missed",
            message = "Dr. Farhana Ahmed tried to call you on encrypted video channel.",
            type = NotificationType.CALL,
            timestamp = "1h ago",
            isRead = false
        ),
        NotificationItem(
            id = "notif_003",
            title = "New Connection Request",
            message = "Sophia Laurent connected with you from New York.",
            type = NotificationType.MESSAGE,
            timestamp = "3h ago",
            isRead = true
        ),
        NotificationItem(
            id = "notif_004",
            title = "Club Activity in Female Founders",
            message = "A new topic 'Pitch Deck Mentorship' was started by Sophia Laurent.",
            type = NotificationType.COMMUNITY,
            timestamp = "5h ago",
            isRead = true
        )
    )

    // Admin Verification Queue
    val initialVerificationRequests = listOf(
        VerificationRequest(
            id = "vr_001",
            user = User(
                id = "usr_010",
                name = "Rumana Kabir",
                username = "rumana_k",
                age = 27,
                dateOfBirth = "1999-03-14",
                city = "Dhaka",
                country = "Bangladesh",
                bio = "Chartered accountant & financial auditor. Eager to join professional women circle. [Test Account]",
                interests = listOf("Finance", "Audit", "Travel"),
                isVerified = false,
                verificationStatus = VerificationStatus.PENDING,
                verificationDocRef = "NID-***-9923-BD"
            ),
            documentType = "National Smart NID",
            documentNumberMasked = "NID-***-9923-BD",
            submittedDate = "Today 09:30 AM",
            status = VerificationStatus.PENDING
        ),
        VerificationRequest(
            id = "vr_002",
            user = User(
                id = "usr_011",
                name = "Claire Bennett",
                username = "claire_b",
                age = 33,
                dateOfBirth = "1993-10-22",
                city = "London",
                country = "United Kingdom",
                bio = "Architectural photographer and landscape designer. [Test Account]",
                interests = listOf("Design", "Nature", "Photography"),
                isVerified = false,
                verificationStatus = VerificationStatus.PENDING,
                verificationDocRef = "PASS-***-7182-UK"
            ),
            documentType = "UK Passport",
            documentNumberMasked = "PASS-***-7182-UK",
            submittedDate = "Yesterday 04:15 PM",
            status = VerificationStatus.PENDING
        )
    )

    // Admin Reports Queue
    val initialAdminReports = listOf(
        AdminReport(
            id = "rep_001",
            reporter = sampleMembers[0],
            reportedUser = User(
                id = "usr_999",
                name = "Suspicious Contact [Flagged]",
                username = "anon_user_99",
                age = 22,
                dateOfBirth = "2004-01-01",
                city = "Unknown",
                country = "International",
                bio = "Suspicious promotional account sending duplicate messages. [Test Flagged Account]",
                isVerified = false,
                verificationStatus = VerificationStatus.UNVERIFIED
            ),
            reason = "Spam & Unsolicited External Links",
            contextNote = "Repeatedly sent automated telegram links to group discussion.",
            status = "PENDING",
            timestamp = "Today 08:20 AM"
        )
    )

    // Security Audit Logs
    val initialSecurityLogs = listOf(
        SecurityAuditLog("log_1", "Identity Document Verified", "usr_001 (Tasnim C.)", "103.205.***.12", "Today 10:00 AM"),
        SecurityAuditLog("log_2", "Encrypted Session Handshake", "conv_001 Peer Connection", "192.0.***.44", "Today 10:15 AM"),
        SecurityAuditLog("log_3", "Admin Access Granted", "admin_001 (Amina R.)", "82.165.***.90", "Today 08:00 AM"),
        SecurityAuditLog("log_4", "Rate Limiter Triggered", "Unknown IP 45.33.***.11 (Blocked)", "45.33.***.11", "Yesterday 11:45 PM")
    )

    // Safety Helplines
    val safetyHelplines = listOf(
        Pair("Bangladesh National Emergency Helpline", "999"),
        Pair("Bangladesh Women & Children Helpline", "109"),
        Pair("Bangladesh Police Emergency Desk", "01320-001299"),
        Pair("UK National Domestic Abuse Helpline", "0808 2000 247"),
        Pair("USA National Domestic Violence Helpline", "1-800-799-7233"),
        Pair("International Women Cyber Safety Center", "+44 20 7946 0912")
    )
}
