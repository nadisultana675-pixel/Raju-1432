package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.User
import com.example.model.VerificationStatus
import com.example.ui.theme.*
import com.example.util.AppLanguage
import com.example.util.Strings

@Composable
fun GoldButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    testTag: String = "gold_button"
) {
    val gradient = if (enabled) {
        Brush.horizontalGradient(listOf(GoldDark, GoldPrimary, GoldAccent))
    } else {
        Brush.horizontalGradient(listOf(Color(0xFF444444), Color(0xFF555555)))
    }

    Surface(
        modifier = modifier
            .height(50.dp)
            .testTag(testTag)
            .clip(RoundedCornerShape(25.dp))
            .clickable(enabled = enabled && !isLoading, onClick = onClick),
        shape = RoundedCornerShape(25.dp),
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(gradient)
                .padding(horizontal = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = DeepBlack,
                    strokeWidth = 2.dp
                )
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (icon != null) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = DeepBlack,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = text,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = DeepBlack,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            letterSpacing = 0.5.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun GoldOutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    testTag: String = "gold_outlined_button"
) {
    Surface(
        modifier = modifier
            .height(48.dp)
            .testTag(testTag)
            .clip(RoundedCornerShape(24.dp))
            .border(1.dp, GoldPrimary, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = GoldPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            )
        }
    }
}

@Composable
fun GoldCard(
    modifier: Modifier = Modifier,
    borderWidth: Dp = 1.dp,
    borderColor: Color = GoldBorder,
    backgroundColor: Color = CardSurface,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(borderWidth, borderColor, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun VerifiedBadge(
    modifier: Modifier = Modifier,
    status: VerificationStatus = VerificationStatus.VERIFIED,
    compact: Boolean = false
) {
    when (status) {
        VerificationStatus.VERIFIED -> {
            Row(
                modifier = modifier
                    .background(Color(0x22D4AF37), RoundedCornerShape(12.dp))
                    .border(1.dp, GoldPrimary, RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = "Verified 18+ Adult Woman",
                    tint = GoldPrimary,
                    modifier = Modifier.size(14.dp)
                )
                if (!compact) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "18+ VERIFIED",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            letterSpacing = 0.5.sp
                        )
                    )
                }
            }
        }
        VerificationStatus.PENDING -> {
            Row(
                modifier = modifier
                    .background(Color(0x22FF9800), RoundedCornerShape(12.dp))
                    .border(1.dp, StatusPending, RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.HourglassTop,
                    contentDescription = "Verification Pending",
                    tint = StatusPending,
                    modifier = Modifier.size(14.dp)
                )
                if (!compact) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "REVIEW PENDING",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = StatusPending,
                            letterSpacing = 0.5.sp
                        )
                    )
                }
            }
        }
        else -> Unit
    }
}

@Composable
fun AvatarWithStatus(
    user: User,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    showOnlineStatus: Boolean = true
) {
    Box(
        modifier = modifier.size(size)
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .border(1.5.dp, GoldPrimary, CircleShape)
                .background(CharcoalBg),
            contentAlignment = Alignment.Center
        ) {
            val resId = user.avatarRes ?: R.drawable.ic_launcher_girls_talk
            androidx.compose.foundation.Image(
                painter = painterResource(id = resId),
                contentDescription = user.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
        }

        if (showOnlineStatus) {
            Box(
                modifier = Modifier
                    .size(size * 0.28f)
                    .clip(CircleShape)
                    .background(if (user.isOnline) StatusOnline else StatusOffline)
                    .border(1.5.dp, DeepBlack, CircleShape)
                    .align(Alignment.BottomEnd)
            )
        }
    }
}

@Composable
fun LuxuryTopBar(
    currentScreenTitle: String,
    language: AppLanguage,
    onLanguageToggle: () -> Unit,
    onSosClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    unreadNotificationCount: Int = 2
) {
    Surface(
        color = DeepBlack,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // App branding
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .border(1.dp, GoldPrimary, CircleShape)
                        .background(CharcoalBg),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.foundation.Image(
                        painter = painterResource(id = R.drawable.ic_launcher_girls_talk),
                        contentDescription = "Logo",
                        modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "GIRLS TALK",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = PlayfairFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = Strings.get("tagline_sub", language),
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 9.sp,
                            color = TextLightGrey
                        )
                    )
                }
            }

            // Actions: Language Toggle + SOS + Notifications
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Language toggle pill
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, GoldBorder, RoundedCornerShape(12.dp))
                        .clickable(onClick = onLanguageToggle),
                    color = CardSurface
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (language == AppLanguage.ENGLISH) "EN" else "বাং",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Switch Language",
                            tint = GoldLight,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // SOS Safety Center
                IconButton(
                    onClick = onSosClick,
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0x33E53935), CircleShape)
                        .border(1.dp, DangerRed, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Safety Center",
                        tint = DangerRed,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Notifications Bell
                Box {
                    IconButton(
                        onClick = onNotificationsClick,
                        modifier = Modifier
                            .size(36.dp)
                            .background(CardSurface, CircleShape)
                            .border(1.dp, GoldBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = GoldLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    if (unreadNotificationCount > 0) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary)
                                .align(Alignment.TopEnd),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$unreadNotificationCount",
                                color = DeepBlack,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LuxuryBottomNav(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    language: AppLanguage,
    unreadMessagesCount: Int = 1
) {
    val items = listOf(
        Triple("home", Strings.get("nav_home", language), Icons.Default.Home to Icons.Outlined.Home),
        Triple("discover", Strings.get("nav_discover", language), Icons.Default.Explore to Icons.Outlined.Explore),
        Triple("chats", Strings.get("nav_chats", language), Icons.Default.Chat to Icons.Outlined.Chat),
        Triple("communities", Strings.get("nav_communities", language), Icons.Default.Groups to Icons.Outlined.Groups),
        Triple("profile", Strings.get("nav_profile", language), Icons.Default.Person to Icons.Outlined.Person)
    )

    Surface(
        color = DeepBlack,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .border(width = 0.5.dp, color = GoldBorder, shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { (route, label, icons) ->
                val isSelected = selectedTab == route
                val (filledIcon, outlinedIcon) = icons

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onTabSelected(route) }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box {
                        Icon(
                            imageVector = if (isSelected) filledIcon else outlinedIcon,
                            contentDescription = label,
                            tint = if (isSelected) GoldPrimary else TextMuted,
                            modifier = Modifier.size(24.dp)
                        )
                        if (route == "chats" && unreadMessagesCount > 0) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(GoldPrimary)
                                    .align(Alignment.TopEnd)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) GoldPrimary else TextMuted
                        )
                    )
                }
            }
        }
    }
}
