package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.User
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.Strings
import com.example.viewmodel.GirlsTalkViewModel
import com.example.viewmodel.UiState

@Composable
fun DiscoverScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    val countries = listOf("All", "Online Now", "Bangladesh", "United States", "United Kingdom", "Canada")

    val filteredMembers = remember(state.members, state.searchQuery, state.selectedCountryFilter) {
        state.members.filter { member ->
            val matchesQuery = state.searchQuery.isBlank() ||
                member.name.contains(state.searchQuery, ignoreCase = true) ||
                member.city.contains(state.searchQuery, ignoreCase = true) ||
                member.country.contains(state.searchQuery, ignoreCase = true) ||
                member.interests.any { it.contains(state.searchQuery, ignoreCase = true) }

            val matchesFilter = when (state.selectedCountryFilter) {
                "All" -> true
                "Online Now" -> member.isOnline
                else -> member.country.equals(state.selectedCountryFilter, ignoreCase = true)
            }

            matchesQuery && matchesFilter
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Search Bar
        OutlinedTextField(
            value = state.searchQuery,
            onValueChange = { viewModel.onSearchQueryChange(it) },
            placeholder = { Text(Strings.get("search_members_hint", lang), color = TextMuted) },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = GoldPrimary)
            },
            trailingIcon = {
                if (state.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = GoldLight)
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("discover_search_bar"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CardSurface,
                unfocusedContainerColor = CardSurface
            ),
            shape = RoundedCornerShape(20.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Country / Status Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(countries) { filterItem ->
                val isSelected = state.selectedCountryFilter == filterItem
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .border(
                            1.dp,
                            if (isSelected) GoldPrimary else GoldBorder,
                            RoundedCornerShape(16.dp)
                        )
                        .clickable { viewModel.setCountryFilter(filterItem) },
                    color = if (isSelected) Color(0x33D4AF37) else CardSurface
                ) {
                    Text(
                        text = filterItem,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (isSelected) GoldLight else TextLightGrey,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        ),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Members Count Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${filteredMembers.size} Verified Adult Women",
                style = MaterialTheme.typography.labelLarge.copy(
                    color = GoldLight,
                    fontWeight = FontWeight.Bold
                )
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Strictly 18+ Private",
                    style = MaterialTheme.typography.labelSmall.copy(color = GoldPrimary, fontSize = 10.sp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Member Cards List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(filteredMembers) { member ->
                MemberCard(
                    member = member,
                    lang = lang,
                    onChatClick = { viewModel.openChatWithMember(member) },
                    onCallClick = { viewModel.startCall(member, isVideo = false) },
                    onVideoCallClick = { viewModel.startCall(member, isVideo = true) },
                    onConnectClick = { viewModel.connectMember(member) },
                    onReportClick = { viewModel.initiateReport(member) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun MemberCard(
    member: User,
    lang: com.example.util.AppLanguage,
    onChatClick: () -> Unit,
    onCallClick: () -> Unit,
    onVideoCallClick: () -> Unit,
    onConnectClick: () -> Unit,
    onReportClick: () -> Unit
) {
    GoldCard(
        modifier = Modifier.fillMaxWidth(),
        borderWidth = 1.dp,
        borderColor = GoldBorder,
        backgroundColor = CardSurface
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            AvatarWithStatus(user = member, size = 60.dp)
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = member.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "@${member.username}",
                                style = MaterialTheme.typography.bodySmall.copy(color = GoldLight)
                            )
                            if (member.privacySettings.showAge) {
                                Text(
                                    text = " • Age: ${member.age}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                                )
                            }
                        }
                    }

                    VerifiedBadge(status = member.verificationStatus)
                }

                if (member.privacySettings.showLocation) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${member.city}, ${member.country}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextLightGrey)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Biography
        Text(
            text = member.bio,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = TextLightGrey,
                lineHeight = 20.sp
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Interests Chips
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            member.interests.take(3).forEach { interest ->
                Surface(
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)),
                    color = CharcoalBg
                ) {
                    Text(
                        text = "#$interest",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = GoldLight,
                            fontSize = 10.sp
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        HorizontalDivider(color = GoldBorder.copy(alpha = 0.3f))

        Spacer(modifier = Modifier.height(10.dp))

        // Actions Row: Message, Audio Call, Video Call, More
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Direct Message
            GoldButton(
                text = Strings.get("start_chat", lang),
                onClick = onChatClick,
                icon = Icons.Default.Chat,
                modifier = Modifier.height(40.dp)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Audio call icon button
                IconButton(
                    onClick = onCallClick,
                    modifier = Modifier
                        .size(38.dp)
                        .background(CharcoalBg, CircleShape)
                        .border(1.dp, GoldBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Audio Call",
                        tint = GoldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Video call icon button
                IconButton(
                    onClick = onVideoCallClick,
                    modifier = Modifier
                        .size(38.dp)
                        .background(CharcoalBg, CircleShape)
                        .border(1.dp, GoldBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Video Call",
                        tint = GoldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Report button
                IconButton(
                    onClick = onReportClick,
                    modifier = Modifier
                        .size(38.dp)
                        .background(CharcoalBg, CircleShape)
                        .border(1.dp, GoldBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Flag,
                        contentDescription = "Report User",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
