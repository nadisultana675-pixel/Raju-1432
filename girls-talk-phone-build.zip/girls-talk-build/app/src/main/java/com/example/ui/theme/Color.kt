package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GIRLS TALK Luxury Black & Gold Palette
val DeepBlack = Color(0xFF080808)
val CharcoalBg = Color(0xFF171717)
val CardSurface = Color(0xFF1E1E1E)
val CardSurfaceElevated = Color(0xFF262626)

val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF3E5AB)
val GoldDark = Color(0xFFAA7C11)
val GoldAccent = Color(0xFFFFD700)
val GoldBorder = Color(0x40D4AF37)

val TextWhite = Color(0xFFFFFFFF)
val TextLightGrey = Color(0xFFBDBDBD)
val TextMuted = Color(0xFF7E7E7E)

val StatusOnline = Color(0xFF4CAF50)
val StatusOffline = Color(0xFF757575)
val StatusPending = Color(0xFFFF9800)
val StatusVerified = Color(0xFFD4AF37)
val DangerRed = Color(0xFFE53935)
val CallGreen = Color(0xFF2E7D32)
