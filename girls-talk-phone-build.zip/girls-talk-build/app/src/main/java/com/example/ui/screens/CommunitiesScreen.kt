package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CommunityGroup
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.AppLanguage
import com.example.util.Strings
import com.example.viewmodel.GirlsTalkViewModel
import com.example.viewmodel.ScreenDestination
import com.example.viewmodel.UiState

@Composable
fun CommunitiesScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "Business", "Health", "Culture", "Technology", "Lifestyle")

    val filteredGroups = remember(state.communityGroups, selectedCategory) {
        if (selectedCategory == "All") state.communityGroups
        else state.communityGroups.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Category Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.take(4).forEach { cat ->
                val isSelected = selectedCategory == cat
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            1.dp,
                            if (isSelected) GoldPrimary else GoldBorder,
                            RoundedCornerShape(14.dp)
                        )
                        .clickable { selectedCategory = cat },
                    color = if (isSelected) Color(0x33D4AF37) else CardSurface
                ) {
                    Text(
                        text = cat,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (isSelected) GoldLight else TextLightGrey,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Community list
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(filteredGroups) { group ->
                GroupCard(
                    group = group,
                    lang = lang,
                    onJoinToggle = { viewModel.toggleGroupJoin(group.id) },
                    onOpenGroupChat = { viewModel.openGroupChat(group) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun GroupCard(
    group: CommunityGroup,
    lang: AppLanguage,
    onJoinToggle: () -> Unit,
    onOpenGroupChat: () -> Unit
) {
    val title = if (lang == AppLanguage.BENGALI) group.nameBn else group.name
    val description = if (lang == AppLanguage.BENGALI) group.descriptionBn else group.description

    GoldCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenGroupChat),
        borderWidth = 1.dp,
        borderColor = GoldBorder,
        backgroundColor = CardSurface
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Color(0x33D4AF37))
                        .border(1.dp, GoldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Groups,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    )
                    Text(
                        text = "${group.memberCount} Verified Sisters",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = GoldLight,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CharcoalBg),
                color = Color.Transparent
            ) {
                Text(
                    text = group.category,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GoldPrimary,
                        fontSize = 10.sp
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = TextLightGrey,
                lineHeight = 20.sp
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Recent discussion preview
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CharcoalBg, RoundedCornerShape(8.dp))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = GoldLight, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Active: \"${group.recentDiscussion}\"",
                style = MaterialTheme.typography.bodySmall.copy(color = TextWhite, fontSize = 11.sp),
                maxLines = 1
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GoldOutlinedButton(
                text = if (group.isJoined) "Joined ✓" else "Join Club",
                onClick = onJoinToggle,
                modifier = Modifier.height(36.dp)
            )

            TextButton(onClick = onOpenGroupChat) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Enter Club Chat", color = GoldPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun GroupChatScreen(
    state: UiState,
    viewModel: GirlsTalkViewModel
) {
    val lang = state.language
    val group = state.activeGroup ?: return
    var messageText by remember { mutableStateOf("") }
    var groupMessages by remember {
        mutableStateOf(
            listOf(
                Pair("Dr. Farhana Ahmed", "Welcome everyone to our specialized discussion! Please feel free to share your thoughts respectfully."),
                Pair("Sophia Laurent", "Great to see so many verified sisters joining this week. Looking forward to our collective growth."),
                Pair("Tasnim Chowdhury", "Thank you for creating this secure space for us.")
            )
        )
    }

    Scaffold(
        topBar = {
            Surface(
                color = DeepBlack,
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .border(0.5.dp, GoldBorder, RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(ScreenDestination.MAIN_CONTAINER) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) group.nameBn else group.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = "${group.memberCount} Verified Sisters • ${group.category}",
                            style = MaterialTheme.typography.bodySmall.copy(color = GoldLight, fontSize = 11.sp)
                        )
                    }
                }
            }
        },
        containerColor = DeepBlack
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Spacer(modifier = Modifier.height(10.dp)) }
                items(groupMessages) { (author, text) ->
                    val isMe = author == state.currentUser.name
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
                    ) {
                        Text(
                            text = author,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (isMe) GoldPrimary else GoldLight,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Surface(
                            modifier = Modifier
                                .widthIn(max = 280.dp)
                                .clip(RoundedCornerShape(14.dp)),
                            color = if (isMe) Color(0xFF2B2207) else CardSurface
                        ) {
                            Text(
                                text = text,
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite),
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }

            // Input
            Surface(
                color = CharcoalBg,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        placeholder = { Text("Message club...", color = TextMuted) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GoldBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedContainerColor = CardSurface,
                            unfocusedContainerColor = CardSurface
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (messageText.isNotBlank()) {
                                groupMessages = groupMessages + Pair(state.currentUser.name, messageText.trim())
                                messageText = ""
                            }
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .background(GoldPrimary, CircleShape)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = DeepBlack, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
